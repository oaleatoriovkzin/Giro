import { P2PRoom, type PeerInfo } from "@/lib/multiplayer";
import type { Vec3Tuple } from "@/game/content";

/** O que cada jogador manda para os outros ~15 vezes por segundo. */
export type Pose = {
  p: Vec3Tuple;
  f: Vec3Tuple;
  /** velocidade com sinal, em m/s */
  s: number;
  /** altura do pulo, em metros */
  h: number;
};

export type NetHandlers = {
  onPeers: (peers: PeerInfo[]) => void;
  onPose: (from: string, pose: Pose) => void;
  /** Mensagens confiáveis (estado das missões em grupo). */
  onEvent: (from: string, data: unknown) => void;
  onConnected: () => void;
};

export type NetSession = {
  selfId: string;
  room: string;
  sendPose: (pose: Pose) => void;
  sendEvent: (data: unknown) => void;
  close: () => void;
};

function vec3(value: unknown): Vec3Tuple | null {
  if (!Array.isArray(value) || value.length !== 3) return null;
  const [x, y, z] = value as unknown[];
  if (typeof x !== "number" || typeof y !== "number" || typeof z !== "number") return null;
  if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z)) return null;
  return [x, y, z];
}

/** Os outros jogadores podem mandar qualquer coisa: valida tudo antes de usar. */
function parsePose(data: unknown): Pose | null {
  if (!data || typeof data !== "object") return null;
  const d = data as Record<string, unknown>;
  if (d.t !== "pose") return null;
  const p = vec3(d.p);
  const f = vec3(d.f);
  if (!p || !f) return null;
  const s = typeof d.s === "number" && Number.isFinite(d.s) ? Math.max(-12, Math.min(12, d.s)) : 0;
  const h = typeof d.h === "number" && Number.isFinite(d.h) ? Math.max(0, Math.min(3, d.h)) : 0;
  return { p, f, s, h };
}

/** Entra numa sala. Quem usa o mesmo nome de sala se encontra; o jogo em si trafega direto entre os navegadores. */
export function openNet(room: string, name: string, handlers: NetHandlers): NetSession {
  const selfId = `p-${Math.random().toString(36).slice(2, 10)}`;
  const p2p = new P2PRoom({
    room,
    selfId,
    name,
    onPeersChanged: handlers.onPeers,
    onConnected: handlers.onConnected,
    onMessage: (from, data, channel) => {
      if (channel === "reliable") {
        handlers.onEvent(from, data);
        return;
      }
      if (channel !== "state") return;
      const pose = parsePose(data);
      if (pose) handlers.onPose(from, pose);
    },
  });
  void p2p.join();
  return {
    selfId,
    room,
    sendPose: (pose) => p2p.broadcast({ t: "pose", ...pose }),
    sendEvent: (data) => p2p.send(data),
    close: () => p2p.close(),
  };
}

/** Quantas pessoas estão na sala agora (sem entrar). Usado para mostrar quem está online. */
export async function peekRoom(room: string): Promise<number> {
  try {
    const res = await fetch(`/api/rtc?room=${encodeURIComponent(room)}&peek=1`, { cache: "no-store" });
    if (!res.ok) return 0;
    const data = (await res.json()) as { count?: unknown };
    return typeof data.count === "number" ? data.count : 0;
  } catch {
    return 0;
  }
}
