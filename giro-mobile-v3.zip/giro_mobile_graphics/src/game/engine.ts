import * as THREE from "three";
import { registerApi } from "@/game/api";
import { GiroAudio } from "@/game/audio";
import { QUEST, RADIUS, placeById, sanitizeSettings, type Settings, type Vec3Tuple } from "@/game/content";
import { createChallenges } from "@/game/challenges";
import { openNet, type NetSession, type Pose } from "@/game/net";
import { emitHudTick, loadSave, useGiro, type PeerView } from "@/game/store";
import type { PeerInfo } from "@/lib/multiplayer";
import {
  buildCharacter,
  buildWorld,
  eastTangent,
  makeLabel,
  orientUp,
  surfaceInto,
  surfacePoint,
  type NpcActor,
  type Rig,
} from "@/game/world";

const START_LON = 0.3;
const WALK = 4.15;
const SPRINT = 7.1;
const REACH = 2.55;
const JUMP_SPEED = 5.4;
const GRAVITY = 16;
const SEND_EVERY_MS = 66;
const STALE_MS = 6000;

const _up = new THREE.Vector3();
const _up2 = new THREE.Vector3();
const _fwd = new THREE.Vector3();
const _right = new THREE.Vector3();
const _wish = new THREE.Vector3();
const _camFwd = new THREE.Vector3();
const _desired = new THREE.Vector3();
const _target = new THREE.Vector3();
const _tangent = new THREE.Vector3();
const _yAxis = new THREE.Vector3(0, 1, 0);

export type InputState = {
  keys: Set<string>;
  stickX: number;
  stickY: number;
  sprint: boolean;
  /** Pedido de pulo: o motor consome e zera. */
  jump: boolean;
  /** Botões de câmera: +1 gira a visão para a esquerda, -1 para a direita. */
  camYaw: number;
  /** +1 sobe a câmera, -1 desce. */
  camPitch: number;
};

export const input: InputState = {
  keys: new Set(),
  stickX: 0,
  stickY: 0,
  sprint: false,
  jump: false,
  camYaw: 0,
  camPitch: 0,
};

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v));
}

function approach(current: number, target: number, delta: number) {
  if (current < target) return Math.min(target, current + delta);
  return Math.max(target, current - delta);
}

function r3(n: number) {
  return Math.round(n * 1000) / 1000;
}

/** Resolução de desenho a partir das configurações (qualidade, resolução e economia de bateria). */
function pixelRatioFor(settings: Settings) {
  const device = window.devicePixelRatio || 1;
  const cap = window.innerWidth < 760 ? 1.5 : 2;
  let ratio = Math.min(device, cap);
  if (settings.quality === "ultra") ratio = Math.min(device, 2);
  if (settings.quality === "baixa") ratio = Math.min(ratio, 1);
  const scale = settings.resolution === "baixa" ? 0.6 : settings.resolution === "media" ? 0.8 : 1;
  ratio *= scale;
  if (settings.battery) ratio = Math.min(ratio, 1);
  return Math.max(0.5, ratio);
}

const _cross = new THREE.Vector3();
const _npcUp = new THREE.Vector3();

function signedAngle(a: THREE.Vector3, b: THREE.Vector3, axis: THREE.Vector3) {
  return Math.atan2(_cross.copy(a).cross(b).dot(axis), a.dot(b));
}

type Remote = {
  id: string;
  name: string;
  rig: Rig;
  pos: THREE.Vector3;
  target: THREE.Vector3;
  fwd: THREE.Vector3;
  targetFwd: THREE.Vector3;
  speed: number;
  height: number;
  phase: number;
  lastSeen: number;
  seen: boolean;
};

const REMOTE_TOPS = [0xe07a5f, 0x3d7ea6, 0xf4efe4, 0x8c6239, 0x7a5aa6, 0xd9a441, 0x4f9d8a];
const REMOTE_BOTTOMS = [0x24362f, 0x2c241c, 0x3a2e26, 0x30425e, 0x4a3a5c];
const REMOTE_HATS = ["cap", "beanie", "bow", "brim"] as const;

function hashString(text: string) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i += 1) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function disposeObject(root: THREE.Object3D) {
  root.traverse((obj) => {
    if (obj instanceof THREE.Mesh) {
      obj.geometry.dispose();
      const mat = obj.material;
      if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
      else mat.dispose();
    }
    if (obj instanceof THREE.Sprite) {
      obj.material.map?.dispose();
      obj.material.dispose();
    }
  });
}

export function mountGiro(canvas: HTMLCanvasElement) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.08;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.setPixelRatio(pixelRatioFor(useGiro.getState().settings));
  renderer.setClearColor(0xb7dff0, 1);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(48, 1, 0.1, 200);
  const world = buildWorld(scene);
  const clouds = scene.getObjectByName("clouds");
  const audio = new GiroAudio();
  const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let reduceMotion = prefersReducedMotion;

  const save = loadSave();
  if (save) {
    useGiro.setState({
      step: save.step,
      elapsed: save.elapsed,
      best: save.best,
      scheme: save.scheme,
      invert: save.invert,
      sensitivity: save.sensitivity,
      camDist: save.camDist,
      muted: save.muted,
      username: save.username ?? "",
      friends: save.friends ?? [],
      settings: sanitizeSettings(save.settings),
      padStyle: save.pad ?? "stick",
      hasSave: save.step > 0 && save.step < QUEST.length,
      screen: "title",
    });
    audio.muted = save.muted;
  }
  const initialSettings = useGiro.getState().settings;
  audio.setVolumes(initialSettings.master / 100, initialSettings.music / 100, initialSettings.effects / 100);

  const pos = surfacePoint(0.06, START_LON);
  const forward = eastTangent(START_LON).multiplyScalar(-1);
  let speed = 0;
  let height = 0;
  let verticalSpeed = 0;
  let yawAccum = 0;
  let phase = 0;
  let stepDist = 0;
  let orbitYaw = 0;
  let orbitPitch = 0;
  let looking = false;
  let lastPointerX = 0;
  let lastPointerY = 0;
  let titleAngle = 0.4;
  let snapCamera = true;
  let lastNear = false;
  let bannerUntil = 0;
  let talkLockUntil = 0;
  let elapsed = useGiro.getState().elapsed;
  let saveClock = 0;
  let dayClock = 0.32;

  const bia = placeById("bia");
  pos.copy(surfacePoint(bia.lat, bia.lon + START_LON));
  forward.copy(eastTangent(bia.lon + START_LON)).multiplyScalar(-1);

  // Continuar volta para onde o jogador parou, não para a casa da Bia.
  if (save?.pos && save.fwd && save.step < QUEST.length) {
    const savedPos = new THREE.Vector3(...save.pos);
    const savedFwd = new THREE.Vector3(...save.fwd);
    if (savedPos.lengthSq() > 1 && savedFwd.lengthSq() > 1e-6) {
      pos.copy(savedPos).setLength(RADIUS);
      const upSaved = _up.copy(pos).normalize();
      savedFwd.addScaledVector(upSaved, -savedFwd.dot(upSaved));
      if (savedFwd.lengthSq() > 1e-6) forward.copy(savedFwd).normalize();
    }
  }

  const timer = new THREE.Timer();
  timer.connect(document);

  const sunLight = scene.children.find((o): o is THREE.DirectionalLight => o instanceof THREE.DirectionalLight);
  let minFrameMs = 0;
  let lastFrameAt = 0;
  let gfxKey = "";

  /** Aplica qualidade, resolução, efeitos, bateria e limite de FPS das configurações. */
  function applyGraphics() {
    const s = useGiro.getState().settings;
    const key = [s.quality, s.resolution, s.reducedFx, s.battery, s.fpsCap].join("|");
    if (key === gfxKey) return;
    gfxKey = key;
    reduceMotion = prefersReducedMotion || s.reducedFx;
    const shadowsOn = s.quality !== "baixa" && !s.reducedFx && !s.battery;
    renderer.shadowMap.enabled = shadowsOn;
    if (sunLight) {
      sunLight.castShadow = shadowsOn;
      const size = s.quality === "media" || window.innerWidth < 760 ? 1024 : 2048;
      if (sunLight.shadow.mapSize.x !== size) {
        sunLight.shadow.mapSize.set(size, size);
        sunLight.shadow.map?.dispose();
        sunLight.shadow.map = null;
      }
    }
    scene.traverse((obj) => {
      if (!(obj instanceof THREE.Mesh)) return;
      const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
      for (const m of mats) m.needsUpdate = true;
    });
    renderer.setPixelRatio(pixelRatioFor(s));
    renderer.setSize(canvas.clientWidth || 1, canvas.clientHeight || 1, false);
    minFrameMs = 1000 / (s.battery ? 30 : s.fpsCap) - 2;
  }

  const unsubscribeSettings = useGiro.subscribe((state, prev) => {
    if (state.settings === prev.settings) return;
    applyGraphics();
    audio.setVolumes(state.settings.master / 100, state.settings.music / 100, state.settings.effects / 100);
  });

  // ───────── controle de videogame ─────────

  let padActive = false;
  let padYaw = 0;
  let padPitch = 0;
  let padSprint = false;
  const padPrev: boolean[] = [];

  function pollGamepad() {
    const s = useGiro.getState().settings;
    if (s.controlMode !== "gamepad" || typeof navigator.getGamepads !== "function") {
      if (padActive) {
        input.stickX = 0;
        input.stickY = 0;
        padActive = false;
      }
      padYaw = 0;
      padPitch = 0;
      padSprint = false;
      return;
    }
    const pad = [...navigator.getGamepads()].find((p): p is Gamepad => p != null && p.connected);
    if (!pad) return;
    const dz = s.deadzone / 100;
    const axis = (i: number) => {
      const v = pad.axes[i] ?? 0;
      return Math.abs(v) < dz ? 0 : v;
    };
    const lx = axis(0);
    const ly = axis(1);
    if (lx !== 0 || ly !== 0) {
      input.stickX = lx;
      input.stickY = -ly;
      padActive = true;
    } else if (padActive) {
      input.stickX = 0;
      input.stickY = 0;
      padActive = false;
    }
    padYaw = -axis(2);
    padPitch = -axis(3);
    const down = (i: number) => pad.buttons[i]?.pressed === true;
    const edge = (i: number) => {
      const now = down(i);
      const was = padPrev[i] === true;
      padPrev[i] = now;
      return now && !was;
    };
    padSprint = down(1) || down(5) || down(7);
    if (edge(0)) input.jump = true;
    if (edge(2)) api.interact();
    if (edge(3)) api.centerCamera();
    if (edge(9)) {
      if (useGiro.getState().screen === "pause") resume();
      else pause();
    }
  }

  function resize() {
    const w = canvas.clientWidth || 1;
    const h = canvas.clientHeight || 1;
    renderer.setPixelRatio(pixelRatioFor(useGiro.getState().settings));
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.fov = w < 760 ? 58 : 48;
    camera.updateProjectionMatrix();
  }

  function placeActor(root: THREE.Object3D, at: THREE.Vector3, face: THREE.Vector3, lift = 0) {
    const up = _up.copy(at).normalize();
    root.position.copy(at).addScaledVector(up, lift);
    orientUp(root, up, face);
  }

  function moveAlong(dir: THREE.Vector3, distance: number) {
    const up = _up.copy(pos).normalize();
    const fwd = _fwd.copy(dir);
    fwd.addScaledVector(up, -fwd.dot(up));
    if (fwd.lengthSq() < 1e-6) return;
    fwd.normalize();
    const right = _right.crossVectors(fwd, up).normalize();
    const angle = distance / RADIUS;
    pos.applyAxisAngle(right, -angle);
    pos.setLength(RADIUS);
    forward.applyAxisAngle(right, -angle);
    const up2 = _up2.copy(pos).normalize();
    forward.addScaledVector(up2, -forward.dot(up2)).normalize();
  }

  function currentNpc(): NpcActor | null {
    const state = useGiro.getState();
    if (state.step >= QUEST.length) return null;
    const id = QUEST[state.step]?.npc;
    return world.npcs.find((npc) => npc.id === id) ?? null;
  }

  function nearest(maxDist: number): NpcActor | null {
    let best: NpcActor | null = null;
    let bestDist = maxDist;
    for (const npc of world.npcs) {
      const d = pos.distanceTo(npc.pos);
      if (d < bestDist) {
        best = npc;
        bestDist = d;
      }
    }
    return best;
  }

  function snapshot(): { pos: Vec3Tuple; fwd: Vec3Tuple } {
    return {
      pos: [r3(pos.x), r3(pos.y), r3(pos.z)],
      fwd: [r3(forward.x), r3(forward.y), r3(forward.z)],
    };
  }

  /** Grava progresso, tempo e posição de uma vez só. */
  function isStory() {
    return useGiro.getState().gameType === "story";
  }

  function saveProgress() {
    // Só a história tem progresso salvo; os desafios em grupo começam sempre do zero.
    if (!isStory()) return;
    useGiro.getState().patch({ elapsed, ...snapshot() });
  }

  function showBanner(text: string) {
    bannerUntil = performance.now() + 1600;
    useGiro.getState().patch({ banner: text });
  }

  function openTalk(npc: NpcActor) {
    const state = useGiro.getState();
    if (state.screen !== "play") return;
    if (performance.now() < talkLockUntil) return;
    const step = QUEST[state.step];
    if (!step) return;
    const advances = step.npc === npc.id;
    const lines = advances
      ? step.lines
      : [`Eu adoraria conversar, mas o recado da vez é com ${placeById(step.npc).name}. Segue a seta coral.`];
    audio.unlock();
    audio.blip();
    useGiro.getState().patch({
      screen: "dialog",
      speaker: npc.name,
      place: npc.place,
      lines,
      lineIndex: 0,
      dialogAdvances: advances,
      dialogStep: state.step,
      near: true,
      nearName: npc.name,
    });
  }

  function advanceDialog() {
    const state = useGiro.getState();
    if (state.screen !== "dialog") return;
    audio.unlock();
    if (state.lineIndex < state.lines.length - 1) {
      audio.blip();
      useGiro.getState().patch({ lineIndex: state.lineIndex + 1 });
      return;
    }
    // Depois de fechar, ignora toques por um instante: o mesmo toque não pode reabrir a conversa.
    talkLockUntil = performance.now() + 350;
    if (!state.dialogAdvances || state.dialogStep !== state.step) {
      useGiro.getState().patch({ screen: "play" });
      return;
    }
    const next = state.step + 1;
    audio.chime();
    if (next >= QUEST.length) {
      const best = state.best == null ? elapsed : Math.min(state.best, elapsed);
      useGiro.getState().patch({
        screen: "done",
        step: next,
        elapsed,
        best,
        banner: null,
        near: false,
        dialogAdvances: false,
        dialogStep: -1,
        pos: null,
        fwd: null,
      });
      return;
    }
    useGiro.getState().patch({
      screen: "play",
      step: next,
      lineIndex: 0,
      dialogAdvances: false,
      dialogStep: -1,
      ...snapshot(),
      elapsed,
    });
    showBanner("Recado anotado");
  }

  function begin(fresh: boolean) {
    challenges.stop();
    useGiro.getState().patch({ gameType: "story", chInfo: null });
    audio.unlock();
    audio.setMuted(useGiro.getState().muted);
    if (fresh || useGiro.getState().step >= QUEST.length) {
      useGiro.getState().patch({ step: 0, elapsed: 0, screen: "play", banner: null, near: false, helpOpen: false, dialogAdvances: false, dialogStep: -1 });
      elapsed = 0;
      const home = placeById("bia");
      pos.copy(surfacePoint(home.lat, home.lon + START_LON));
      forward.copy(eastTangent(home.lon + START_LON)).multiplyScalar(-1);
      speed = 0;
      height = 0;
      verticalSpeed = 0;
      yawAccum = 0;
      saveProgress();
    } else {
      useGiro.getState().patch({ screen: "play" });
    }
    orbitYaw = 0;
    orbitPitch = 0;
    snapCamera = true;
    showBanner(useGiro.getState().mode === "multi" ? "Sala aberta. Siga a seta coral" : "Siga a seta coral");
  }

  function restart() {
    if (useGiro.getState().gameType === "challenges") startChallenges();
    else begin(true);
  }

  function pause() {
    const screen = useGiro.getState().screen;
    if (screen !== "play" && screen !== "dialog") return;
    useGiro.getState().patch({ screen: "pause", returnScreen: screen === "dialog" ? "dialog" : "play" });
    saveProgress();
  }

  function resume() {
    if (useGiro.getState().screen !== "pause") return;
    const back = useGiro.getState().returnScreen === "dialog" ? "dialog" : "play";
    useGiro.getState().patch({ screen: back });
  }

  // ───────── desafios em grupo ─────────

  const challenges = createChallenges({
    scene,
    getPlayer: () => ({ pos, height }),
    getOthers: () =>
      [...remotes.values()].filter((r) => r.rig.root.visible).map((r) => ({ pos: r.pos, height: r.height })),
    getConnectedPeers: () => useGiro.getState().peers.filter((p) => p.state === "connected").length,
    send: (msg) => net?.sendEvent(msg),
    onSound: (kind) => {
      if (kind === "pick") audio.pick();
      else if (kind === "fail") audio.fail();
      else if (kind === "win") audio.chime();
      else audio.blip();
      if (useGiro.getState().settings.vibration && "vibrate" in navigator) {
        navigator.vibrate(kind === "win" ? [60, 40, 90] : kind === "fail" ? 120 : 25);
      }
    },
    onInfo: (info) => useGiro.getState().patch({ chInfo: info }),
    onToast: (text) => showBanner(text),
  });

  function startChallenges() {
    audio.unlock();
    useGiro.getState().patch({
      gameType: "challenges",
      screen: "play",
      banner: null,
      near: false,
      helpOpen: false,
      chInfo: null,
    });
    const home = placeById("bia");
    pos.copy(surfacePoint(home.lat, home.lon + START_LON));
    forward.copy(eastTangent(home.lon + START_LON)).multiplyScalar(-1);
    speed = 0;
    height = 0;
    verticalSpeed = 0;
    orbitYaw = 0;
    orbitPitch = 0;
    snapCamera = true;
    world.guide.visible = false;
    challenges.start(Date.now());
  }

  // ───────── multiplayer ─────────

  let net: NetSession | null = null;
  let lastSend = 0;
  const remotes = new Map<string, Remote>();

  function ensureRemote(id: string, name: string): Remote {
    const existing = remotes.get(id);
    if (existing) return existing;
    const h = hashString(id);
    const rig = buildCharacter({
      top: REMOTE_TOPS[h % REMOTE_TOPS.length] ?? 0xe07a5f,
      bottom: REMOTE_BOTTOMS[(h >>> 3) % REMOTE_BOTTOMS.length] ?? 0x24362f,
      hat: REMOTE_HATS[(h >>> 6) % REMOTE_HATS.length] ?? "cap",
      scale: 1,
    });
    const label = makeLabel(name || "Jogador");
    label.position.y = 2.15;
    rig.root.add(label);
    rig.root.visible = false;
    scene.add(rig.root);
    const remote: Remote = {
      id,
      name,
      rig,
      pos: pos.clone(),
      target: pos.clone(),
      fwd: forward.clone(),
      targetFwd: forward.clone(),
      speed: 0,
      height: 0,
      phase: 0,
      lastSeen: performance.now(),
      seen: false,
    };
    remotes.set(id, remote);
    return remote;
  }

  function removeRemote(id: string) {
    const remote = remotes.get(id);
    if (!remote) return;
    scene.remove(remote.rig.root);
    disposeObject(remote.rig.root);
    remotes.delete(id);
  }

  function clearRemotes() {
    for (const id of [...remotes.keys()]) removeRemote(id);
  }

  function onPeers(list: PeerInfo[]) {
    const alive = new Set<string>();
    for (const peer of list) {
      alive.add(peer.id);
      if (!remotes.has(peer.id)) challenges.resend(Date.now());
      const remote = ensureRemote(peer.id, peer.name);
      if (remote.name !== peer.name && peer.name) {
        // Nome mudou (ou chegou depois): recria o rótulo.
        removeRemote(peer.id);
        ensureRemote(peer.id, peer.name);
      }
    }
    for (const id of [...remotes.keys()]) {
      if (!alive.has(id)) removeRemote(id);
    }
    const views: PeerView[] = list.map((peer) => ({ id: peer.id, name: peer.name || "Jogador", state: peer.connectionState }));
    useGiro.getState().patch({ peers: views });
  }

  function onPose(from: string, pose: Pose) {
    const remote = remotes.get(from) ?? ensureRemote(from, from);
    remote.target.set(...pose.p);
    if (remote.target.lengthSq() < 1) return;
    remote.target.setLength(RADIUS);
    const up = _up.copy(remote.target).normalize();
    const f = _fwd.set(...pose.f);
    f.addScaledVector(up, -f.dot(up));
    if (f.lengthSq() > 1e-6) remote.targetFwd.copy(f).normalize();
    remote.speed = pose.s;
    remote.height = pose.h;
    remote.lastSeen = performance.now();
    if (!remote.seen) {
      remote.seen = true;
      remote.pos.copy(remote.target);
      remote.fwd.copy(remote.targetFwd);
    }
  }

  function startMulti(room: string, name: string) {
    leaveMulti();
    useGiro.getState().patch({ mode: "multi", netStatus: "connecting", room, peers: [] });
    net = openNet(room, name, {
      onPeers,
      onPose,
      onEvent: (_from, data) => challenges.receive(data),
      onConnected: () => useGiro.getState().patch({ netStatus: "online" }),
    });
  }

  function leaveMulti() {
    net?.close();
    net = null;
    clearRemotes();
    useGiro.getState().patch({ mode: "solo", netStatus: "off", room: "", peers: [] });
  }

  function toTitle() {
    leaveMulti();
    saveProgress();
    challenges.stop();
    useGiro.getState().patch({ chInfo: null });
    const step = useGiro.getState().step;
    useGiro.getState().patch({
      screen: "title",
      hasSave: step > 0 && step < QUEST.length,
      helpOpen: false,
      near: false,
      banner: null,
    });
  }

  function sendPose(now: number) {
    if (!net || now - lastSend < SEND_EVERY_MS) return;
    lastSend = now;
    net.sendPose({
      p: [r3(pos.x), r3(pos.y), r3(pos.z)],
      f: [r3(forward.x), r3(forward.y), r3(forward.z)],
      s: r3(speed),
      h: r3(height),
    });
  }

  function updateRemotes(dt: number) {
    if (remotes.size === 0) return;
    const now = performance.now();
    const k = 1 - Math.exp(-12 * dt);
    for (const remote of remotes.values()) {
      const stale = now - remote.lastSeen > STALE_MS;
      remote.rig.root.visible = remote.seen && !stale;
      if (!remote.rig.root.visible) continue;
      remote.pos.lerp(remote.target, k).setLength(RADIUS);
      remote.fwd.lerp(remote.targetFwd, k);
      const moving = Math.abs(remote.speed) > 0.3;
      if (moving) remote.phase += dt * Math.abs(remote.speed) * 2.4;
      const swing = Math.sin(remote.phase) * clamp(Math.abs(remote.speed) / WALK, 0, 1);
      const airborne = remote.height > 0.02;
      const bob = reduceMotion || !moving ? 0 : Math.abs(Math.sin(remote.phase)) * 0.05;
      placeActor(remote.rig.root, remote.pos, remote.fwd, airborne ? remote.height : bob);
      remote.rig.leftLeg.rotation.x = airborne ? 0.5 : swing * 0.7;
      remote.rig.rightLeg.rotation.x = airborne ? -0.2 : -swing * 0.7;
      remote.rig.leftArm.rotation.x = airborne ? -2.3 : -swing * 0.45;
      remote.rig.rightArm.rotation.x = airborne ? -2.3 : swing * 0.45;
    }
  }

  const api = {
    begin,
    interact() {
      const screen = useGiro.getState().screen;
      audio.unlock();
      if (screen === "dialog") {
        advanceDialog();
        return;
      }
      if (screen !== "play" || !isStory()) return;
      const npc = nearest(REACH);
      if (npc) openTalk(npc);
    },
    pause,
    resume,
    restart,
    openHelp() {
      useGiro.getState().patch({ helpOpen: true });
    },
    closeHelp() {
      useGiro.getState().patch({ helpOpen: false });
    },
    centerCamera() {
      orbitYaw = 0;
      orbitPitch = 0;
      snapCamera = true;
    },
    jump() {
      input.jump = true;
    },
    zoom(delta: number) {
      const next = clamp(useGiro.getState().camDist + delta, 4.2, 9);
      useGiro.getState().setCamDist(next);
    },
    startMulti,
    leaveMulti,
    toTitle,
    startChallenges,
    uiBlip() {
      audio.unlock();
      audio.blip();
    },
  };
  registerApi(api);

  function onKeyDown(event: KeyboardEvent) {
    // Quem está digitando (o username, por exemplo) não mexe no jogo.
    const typing = event.target;
    if (typing instanceof HTMLInputElement || typing instanceof HTMLTextAreaElement) return;
    input.keys.add(event.code);
    if (event.code === "Space" || event.code.startsWith("Arrow")) event.preventDefault();
    const inGame = useGiro.getState().screen === "play" || useGiro.getState().screen === "dialog";
    if (inGame && (event.code === "Space" || event.code === "Enter")) {
      // Um botão em foco também reagiria ao Enter/Espaço e contaria o toque duas vezes.
      const active = document.activeElement;
      if (active instanceof HTMLButtonElement) active.blur();
    }
    if (event.repeat) return;
    if (event.code === "Escape") {
      if (useGiro.getState().helpOpen) {
        api.closeHelp();
        return;
      }
      const screen = useGiro.getState().screen;
      if (screen === "pause") resume();
      else pause();
    }
    if (event.code === "KeyE") api.interact();
    if (event.code === "Enter" && inGame) {
      event.preventDefault();
      api.interact();
    }
    if (event.code === "Space" && useGiro.getState().screen === "play") input.jump = true;
    if (event.code === "KeyC") {
      orbitYaw = 0;
      orbitPitch = 0;
    }
  }

  function onKeyUp(event: KeyboardEvent) {
    input.keys.delete(event.code);
  }

  function clearKeys() {
    input.keys.clear();
    input.sprint = false;
    input.jump = false;
    input.camYaw = 0;
    input.camPitch = 0;
  }

  function onPointerDown(event: PointerEvent) {
    if (event.button !== 0) return;
    const screen = useGiro.getState().screen;
    if (screen !== "play") return;
    looking = true;
    lastPointerX = event.clientX;
    lastPointerY = event.clientY;
  }

  function onPointerUp() {
    looking = false;
  }

  function onPointerMove(event: PointerEvent) {
    if (!looking) return;
    const sens = 0.0045 * useGiro.getState().sensitivity;
    const dx = event.clientX - lastPointerX;
    const dy = event.clientY - lastPointerY;
    lastPointerX = event.clientX;
    lastPointerY = event.clientY;
    orbitYaw -= dx * sens;
    const ySign = useGiro.getState().settings.invertY ? -1 : 1;
    orbitPitch = clamp(orbitPitch + dy * sens * 0.65 * ySign, -0.35, 0.55);
  }

  function onHide() {
    if (document.visibilityState === "hidden") saveProgress();
  }

  function onPageHide() {
    saveProgress();
    net?.close();
    net = null;
  }

  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("keyup", onKeyUp);
  window.addEventListener("blur", clearKeys);
  window.addEventListener("pagehide", onPageHide);
  document.addEventListener("visibilitychange", onHide);
  canvas.addEventListener("pointerdown", onPointerDown);
  window.addEventListener("pointerup", onPointerUp);
  window.addEventListener("pointermove", onPointerMove);
  const onResize = () => resize();
  window.addEventListener("resize", onResize);
  const observer = new ResizeObserver(() => resize());
  observer.observe(canvas);
  resize();

  window.__controlsTest = {
    getYaw: () => yawAccum,
    getSpeed: () => Math.abs(speed),
    setKeys: (codes) => {
      input.keys.clear();
      for (const code of codes) input.keys.add(code);
    },
  };

  function readMove() {
    const state = useGiro.getState();
    let ix = 0;
    let iz = 0;
    let steer = 0;
    const keys = input.keys;
    const left = keys.has("KeyA") || keys.has("ArrowLeft");
    const right = keys.has("KeyD") || keys.has("ArrowRight");
    const forwardKey = keys.has("KeyW") || keys.has("ArrowUp");
    const back = keys.has("KeyS") || keys.has("ArrowDown");
    if (state.scheme === "volante") {
      if (left) steer += 1;
      if (right) steer -= 1;
      if (forwardKey) iz += 1;
      if (back) iz -= 1;
      iz += input.stickY;
      steer += -input.stickX;
    } else {
      if (left) ix -= 1;
      if (right) ix += 1;
      if (forwardKey) iz += 1;
      if (back) iz -= 1;
      iz += input.stickY;
      ix += input.stickX;
    }
    if (state.invert) {
      ix = -ix;
      steer = -steer;
    }
    const sprint = keys.has("ShiftLeft") || keys.has("ShiftRight") || input.sprint || padSprint;
    return {
      ix: clamp(ix, -1, 1),
      iz: clamp(iz, -1, 1),
      steer: clamp(steer, -1, 1),
      sprint,
    };
  }

  function simulate(dt: number) {
    const state = useGiro.getState();
    const up = _up.copy(pos).normalize();
    const playing = state.screen === "play" && !state.helpOpen;
    if (playing) {
      const move = readMove();
      const maxSpeed = move.sprint ? SPRINT : WALK;
      if (state.scheme === "volante") {
        const turn = move.steer * 2.45 * state.sensitivity * dt;
        if (turn !== 0) {
          forward.applyAxisAngle(up, turn);
          yawAccum += turn;
          forward.addScaledVector(up, -forward.dot(up)).normalize();
        }
        const target = move.iz * maxSpeed;
        speed = approach(speed, target, 16 * dt);
        if (Math.abs(speed) > 0.02) moveAlong(forward, speed * dt);
      } else {
        _camFwd.copy(forward).applyAxisAngle(up, orbitYaw);
        _camFwd.addScaledVector(up, -_camFwd.dot(up)).normalize();
        const camRight = _right.crossVectors(_camFwd, up).normalize();
        _wish.copy(_camFwd).multiplyScalar(move.iz).addScaledVector(camRight, move.ix);
        const len = _wish.length();
        if (len > 0.08) {
          _wish.multiplyScalar(1 / Math.min(1, len));
          const wishDir = _fwd.copy(_wish).normalize();
          const ang = signedAngle(forward, wishDir, up);
          const stepTurn = clamp(ang, -7.5 * state.sensitivity * dt, 7.5 * state.sensitivity * dt);
          if (stepTurn !== 0) {
            forward.applyAxisAngle(up, stepTurn);
            yawAccum += stepTurn;
            forward.addScaledVector(up, -forward.dot(up)).normalize();
          }
          speed = approach(speed, maxSpeed * Math.min(1, len), 16 * dt);
          moveAlong(wishDir, speed * dt);
        } else {
          speed = approach(speed, 0, 18 * dt);
        }
      }

      // Pulo: só sai do chão; no ar a gravidade puxa de volta.
      if (input.jump) {
        input.jump = false;
        if (height <= 0.001) {
          verticalSpeed = JUMP_SPEED;
          height = 0.002;
          audio.jump();
        }
      }

      // Botões de câmera
      const yawIn = clamp(input.camYaw + padYaw, -1, 1);
      const pitchIn = clamp(input.camPitch + padPitch, -1, 1) * (state.settings.invertY ? -1 : 1);
      if (yawIn !== 0) orbitYaw += yawIn * 1.9 * dt;
      if (pitchIn !== 0) orbitPitch = clamp(orbitPitch + pitchIn * 0.9 * dt, -0.35, 0.55);
      const holdingCamera = looking || yawIn !== 0 || pitchIn !== 0;
      if (!holdingCamera) {
        const back = 1 - Math.exp(-3.2 * dt);
        orbitYaw += (0 - orbitYaw) * back;
        orbitPitch += (0 - orbitPitch) * back;
      }

      if (height <= 0.001 && Math.abs(speed) > 0.45) {
        phase += dt * Math.abs(speed) * 2.4;
        stepDist += Math.abs(speed) * dt;
        if (stepDist > 1.25) {
          stepDist = 0;
          audio.foot();
        }
      }
      elapsed += dt;
      saveClock += dt;
      if (saveClock > 2) {
        saveClock = 0;
        saveProgress();
      }
    } else {
      input.jump = false;
    }

    if (height > 0) {
      verticalSpeed -= GRAVITY * dt;
      height += verticalSpeed * dt;
      if (height <= 0) {
        height = 0;
        verticalSpeed = 0;
        if (Math.abs(speed) > 0.45) audio.foot();
      }
    }

    const airborne = height > 0.001;
    const bob = airborne || reduceMotion || Math.abs(speed) < 0.3 ? 0 : Math.abs(Math.sin(phase)) * 0.05;
    placeActor(world.player.root, pos, forward, airborne ? height : bob);
    const swing = Math.sin(phase) * clamp(Math.abs(speed) / WALK, 0, 1);
    world.player.leftLeg.rotation.x = airborne ? 0.5 : swing * 0.7;
    world.player.rightLeg.rotation.x = airborne ? -0.2 : -swing * 0.7;
    world.player.leftArm.rotation.x = airborne ? -2.3 : -swing * 0.45;
    world.player.rightArm.rotation.x = airborne ? -2.3 : swing * 0.45;

    const now = performance.now() * 0.001;
    for (const npc of world.npcs) {
      const idle = reduceMotion ? 0 : Math.sin(now * 1.6 + npc.pos.x) * 0.03;
      const face = _fwd.copy(pos).sub(npc.pos);
      const nUp = _up2.copy(npc.pos).normalize();
      face.addScaledVector(nUp, -face.dot(nUp));
      if (face.lengthSq() < 1e-4) face.copy(eastTangent(0));
      placeActor(npc.rig.root, npc.pos, face.normalize(), idle);
    }

    const story = state.gameType === "story";
    const goal = story ? currentNpc() : null;
    const nearNpc = story ? nearest(REACH) : null;
    const near = state.screen === "play" && nearNpc != null;
    if (near !== lastNear || (near && nearNpc && nearNpc.name !== state.nearName)) {
      lastNear = near;
      useGiro.getState().patch({ near, nearName: nearNpc?.name ?? "" });
    }
    if (state.banner && performance.now() > bannerUntil) {
      useGiro.getState().patch({ banner: null });
    }

    if (goal && state.screen === "play") {
      const to = _tangent.copy(goal.pos).sub(pos);
      const upNow = _up.copy(pos).normalize();
      to.addScaledVector(upNow, -to.dot(upNow));
      const dist = to.length();
      if (dist > 0.001) to.multiplyScalar(1 / dist);
      const bearing = signedAngle(forward, to, upNow);
      const meters =
        Math.acos(clamp(_up2.copy(pos).normalize().dot(_npcUp.copy(goal.pos).normalize()), -1, 1)) * RADIUS;
      emitHudTick({ meters, bearing, elapsed });
      world.guide.visible = meters > REACH;
      world.guide.position.copy(pos).addScaledVector(upNow, 2.35 + height).addScaledVector(to, 0.35);
      world.guide.quaternion.setFromUnitVectors(_yAxis, to);
      const pulse = 1 + Math.sin(now * 5) * (reduceMotion ? 0 : 0.08);
      world.guide.scale.setScalar(pulse);
    } else {
      world.guide.visible = false;
      if (state.screen !== "play") emitHudTick({ meters: 0, bearing: 0, elapsed });
    }

    if (clouds) clouds.rotation.y += dt * 0.03;
  }

  function frameCamera(dt: number) {
    const state = useGiro.getState();
    if (state.screen === "title" || state.screen === "done") {
      titleAngle += dt * 0.12;
      surfaceInto(_desired, 0.42, titleAngle, RADIUS * 1.72);
      camera.position.copy(_desired);
      camera.up.copy(_desired).normalize();
      surfaceInto(_target, 0.1, titleAngle + 0.55, RADIUS * 0.15);
      camera.lookAt(_target);
      return;
    }
    const up = _up.copy(pos).normalize();
    const lookFwd = _camFwd.copy(forward).applyAxisAngle(up, orbitYaw);
    const camHeight = 2.15 + orbitPitch + height * 0.35;
    _target.copy(pos).addScaledVector(up, 1.25 + height * 0.6);
    _desired.copy(pos).addScaledVector(up, camHeight).addScaledVector(lookFwd, -state.camDist);
    if (_desired.length() < RADIUS + 1.1) _desired.setLength(RADIUS + 1.1);
    if (snapCamera) {
      camera.position.copy(_desired);
      snapCamera = false;
    } else {
      const k = 1 - Math.exp(-(reduceMotion ? 14 : 7) * dt);
      camera.position.lerp(_desired, k);
    }
    camera.up.copy(up);
    camera.lookAt(_target);
  }

  let acc = 0;
  let dead = false;
  function loop() {
    if (dead) return;
    const frameNow = performance.now();
    if (minFrameMs > 0 && frameNow - lastFrameAt < minFrameMs) return;
    lastFrameAt = frameNow;
    timer.update();
    const dt = Math.min(timer.getDelta(), 0.05);
    dayClock = (dayClock + dt / 210) % 1;
    world.updateEnvironment(dayClock, pos);
    audio.resume();
    audio.tick();
    pollGamepad();
    acc += dt;
    if (acc > 0.12) acc = 0.12;
    const step = 1 / 60;
    while (acc >= step) {
      simulate(step);
      acc -= step;
    }
    const now = useGiro.getState();
    if (now.gameType === "challenges") {
      challenges.update(dt, Date.now(), now.screen === "play" && !now.helpOpen);
      if (now.chInfo?.phase === "done" && (now.screen === "play" || now.screen === "dialog")) {
        now.patch({ screen: "done" });
      }
    }
    updateRemotes(dt);
    sendPose(performance.now());
    frameCamera(dt);
    renderer.render(scene, camera);
  }
  applyGraphics();
  renderer.setAnimationLoop(loop);
  useGiro.getState().patch({ ready: true });

  return function dispose() {
    dead = true;
    renderer.setAnimationLoop(null);
    registerApi(null);
    unsubscribeSettings();
    challenges.dispose();
    net?.close();
    net = null;
    clearRemotes();
    delete window.__controlsTest;
    window.removeEventListener("keydown", onKeyDown);
    window.removeEventListener("keyup", onKeyUp);
    window.removeEventListener("blur", clearKeys);
    window.removeEventListener("pagehide", onPageHide);
    document.removeEventListener("visibilitychange", onHide);
    window.removeEventListener("pointerup", onPointerUp);
    window.removeEventListener("pointermove", onPointerMove);
    window.removeEventListener("resize", onResize);
    canvas.removeEventListener("pointerdown", onPointerDown);
    observer.disconnect();
    world.dispose();
    renderer.dispose();
    timer.dispose();
  };
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys?: (codes: string[]) => void;
    };
  }
}

