export const RADIUS = 16;

export type NpcId = "bia" | "sol" | "rosa" | "nico" | "luna" | "nuvem";

export type PlaceKind = "post" | "light" | "garden" | "shop" | "school" | "park";

export type Place = {
  id: NpcId;
  name: string;
  place: string;
  lat: number;
  lon: number;
  top: number;
  bottom: number;
  hat: "cap" | "brim" | "beanie" | "bow";
  kind: PlaceKind;
  scale: number;
};

export const PLACES: Place[] = [
  {
    id: "bia",
    name: "Bia",
    place: "Agência",
    lat: 0.06,
    lon: 0,
    top: 0x2f6b5a,
    bottom: 0x24362f,
    hat: "cap",
    kind: "post",
    scale: 1,
  },
  {
    id: "sol",
    name: "Sol",
    place: "Farol",
    lat: 0.48,
    lon: 1.08,
    top: 0xf4efe4,
    bottom: 0x8c6239,
    hat: "brim",
    kind: "light",
    scale: 1,
  },
  {
    id: "rosa",
    name: "Rosa",
    place: "Horta",
    lat: -0.32,
    lon: 2.15,
    top: 0xe07a5f,
    bottom: 0x2f6b5a,
    hat: "bow",
    kind: "garden",
    scale: 1,
  },
  {
    id: "nico",
    name: "Nico",
    place: "Oficina",
    lat: 0.22,
    lon: 3.22,
    top: 0x8c6239,
    bottom: 0x3a2e26,
    hat: "beanie",
    kind: "shop",
    scale: 1.02,
  },
  {
    id: "luna",
    name: "Luna",
    place: "Escola",
    lat: -0.12,
    lon: 4.28,
    top: 0x3d7ea6,
    bottom: 0x2c241c,
    hat: "bow",
    kind: "school",
    scale: 1,
  },
  {
    id: "nuvem",
    name: "Nuvem",
    place: "Parque",
    lat: 0.36,
    lon: 5.35,
    top: 0xf4efe4,
    bottom: 0x2f6b5a,
    hat: "beanie",
    kind: "park",
    scale: 0.82,
  },
];

export type QuestStep = {
  npc: NpcId;
  objective: string;
  carrying: string | null;
  lines: string[];
};

export const QUEST: QuestStep[] = [
  {
    npc: "bia",
    objective: "Fale com a Bia na agência",
    carrying: null,
    lines: [
      "Oi. Eu sou a Bia. Este planeta cabe numa caminhada, mas as encomendas não andam sozinhas.",
      "Leva o carimbo novo para o Sol, no farol. Sem carimbo, ele trata o diário como rascunho.",
    ],
  },
  {
    npc: "sol",
    objective: "Entregue o carimbo ao Sol",
    carrying: "Carimbo novo",
    lines: [
      "Carimbo à vista. O diário acaba de ficar oficial.",
      "A Rosa pediu um mapa da horta. Ela rega a cerca e esquece os morangos. Você leva?",
    ],
  },
  {
    npc: "rosa",
    objective: "Leve o mapa para a Rosa",
    carrying: "Mapa da horta",
    lines: [
      "Olha só o mapa. A cerca fica exatamente onde eu imaginava.",
      "Leva este potinho de morangos para o Nico, na oficina. Ele consertou o regador e só aceita pagamento doce.",
    ],
  },
  {
    npc: "nico",
    objective: "Leve os morangos ao Nico",
    carrying: "Morangos",
    lines: [
      "Morango recebido. Até a chave de fenda parece mais leve.",
      "A Luna esqueceu o apito da escola aqui. Devolve antes que o recreio vire sussurro.",
    ],
  },
  {
    npc: "luna",
    objective: "Devolva o apito à Luna",
    carrying: "Apito da escola",
    lines: [
      "O apito voltou. A turma já estava contando em silêncio até dez.",
      "Eles desenharam o planeta inteiro. Entrega para a Nuvem, no parque. É para mostrar hoje.",
    ],
  },
  {
    npc: "nuvem",
    objective: "Entregue o desenho à Nuvem",
    carrying: "Desenho da turma",
    lines: [
      "Somos nós, bem pequenininhos, dando a volta no mundo.",
      "Fiz um obrigado para a Bia. Você fecha o giro?",
    ],
  },
  {
    npc: "bia",
    objective: "Feche a volta com a Bia",
    carrying: "Cartão de obrigado",
    lines: [
      "Volta fechada. Sete recados, nenhuma carta no chão.",
      "O planeta continua pequeno. O caminho que você fez, não.",
    ],
  },
];

export function placeById(id: NpcId): Place {
  const place = PLACES.find((p) => p.id === id);
  if (!place) throw new Error(`lugar desconhecido: ${id}`);
  return place;
}

export const SAVE_KEY = "giro-save-v1";

export type Scheme = "volante" | "livre";

export type PadStyle = "stick" | "buttons";

export type Vec3Tuple = [number, number, number];

export type Quality = "baixa" | "media" | "alta" | "ultra";
export type Resolution = "baixa" | "media" | "alta";
export type ScreenMode = "cheia" | "janela" | "semborda";
export type ControlMode = "touch" | "teclado" | "gamepad";

/** Tudo que a tela de Configurações do menu controla. Volumes e zona morta em 0-100. */
export type Settings = {
  quality: Quality;
  resolution: Resolution;
  screenMode: ScreenMode;
  fpsCap: number;
  reducedFx: boolean;
  battery: boolean;
  master: number;
  music: number;
  effects: number;
  menuSound: boolean;
  vibration: boolean;
  controlMode: ControlMode;
  deadzone: number;
  invertY: boolean;
  showTips: boolean;
  animations: boolean;
};

export const DEFAULT_SETTINGS: Settings = {
  quality: "alta",
  resolution: "alta",
  screenMode: "cheia",
  fpsCap: 60,
  reducedFx: false,
  battery: false,
  master: 80,
  music: 70,
  effects: 80,
  menuSound: true,
  vibration: true,
  controlMode: "touch",
  deadzone: 10,
  invertY: false,
  showTips: true,
  animations: true,
};

function pick<T extends string>(value: unknown, allowed: readonly T[], fallback: T): T {
  return typeof value === "string" && (allowed as readonly string[]).includes(value) ? (value as T) : fallback;
}

function num(value: unknown, min: number, max: number, fallback: number) {
  return typeof value === "number" && Number.isFinite(value) ? Math.max(min, Math.min(max, value)) : fallback;
}

function bool(value: unknown, fallback: boolean) {
  return typeof value === "boolean" ? value : fallback;
}

/** Aceita qualquer coisa vinda do navegador e devolve configurações válidas. */
export function sanitizeSettings(raw: unknown): Settings {
  const d = DEFAULT_SETTINGS;
  const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  return {
    quality: pick(r.quality, ["baixa", "media", "alta", "ultra"] as const, d.quality),
    resolution: pick(r.resolution, ["baixa", "media", "alta"] as const, d.resolution),
    screenMode: pick(r.screenMode, ["cheia", "janela", "semborda"] as const, d.screenMode),
    fpsCap: [30, 60, 90, 120].includes(r.fpsCap as number) ? (r.fpsCap as number) : d.fpsCap,
    reducedFx: bool(r.reducedFx, d.reducedFx),
    battery: bool(r.battery, d.battery),
    master: num(r.master, 0, 100, d.master),
    music: num(r.music, 0, 100, d.music),
    effects: num(r.effects, 0, 100, d.effects),
    menuSound: bool(r.menuSound, d.menuSound),
    vibration: bool(r.vibration, d.vibration),
    controlMode: pick(r.controlMode, ["touch", "teclado", "gamepad"] as const, d.controlMode),
    deadzone: num(r.deadzone, 0, 40, d.deadzone),
    invertY: bool(r.invertY, d.invertY),
    showTips: bool(r.showTips, d.showTips),
    animations: bool(r.animations, d.animations),
  };
}

export type SaveData = {
  v: 1;
  step: number;
  elapsed: number;
  best: number | null;
  scheme: Scheme;
  invert: boolean;
  sensitivity: number;
  camDist: number;
  muted: boolean;
  username?: string;
  friends?: string[];
  settings?: Partial<Settings>;
  pad?: PadStyle;
  pos?: Vec3Tuple;
  fwd?: Vec3Tuple;
};

/** Username limpo: minúsculas, sem acento, só letras, números, _ e -. */
export function cleanUsername(raw: string) {
  return raw
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, "")
    .slice(0, 20);
}

/** A sala de alguém é sempre "u-<username>", então basta saber o username para entrar. */
export function roomForUsername(raw: string) {
  const user = cleanUsername(raw);
  return user ? `u-${user}` : "";
}
