export class GiroAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private music: GainNode | null = null;
  private sfx: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private nextNote = 0;
  private noteIndex = 0;
  muted = false;
  private volMaster = 0.8;
  private volMusic = 0.7;
  private volEffects = 0.8;

  unlock() {
    if (!this.ctx) {
      const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new Ctx({ latencyHint: "interactive" });
      this.ctx = ctx;
      this.master = ctx.createGain();
      this.music = ctx.createGain();
      this.sfx = ctx.createGain();
      this.music.gain.value = 0.45 * this.volMusic;
      this.sfx.gain.value = 0.7 * this.volEffects;
      this.music.connect(this.master);
      this.sfx.connect(this.master);
      this.master.connect(ctx.destination);
      this.master.gain.value = this.muted ? 0 : this.volMaster;
      const seconds = 0.12;
      const buffer = ctx.createBuffer(1, Math.floor(ctx.sampleRate * seconds), ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < data.length; i += 1) data[i] = Math.random() * 2 - 1;
      this.noise = buffer;
      this.nextNote = ctx.currentTime + 0.05;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  resume() {
    if (this.ctx && this.ctx.state === "suspended") void this.ctx.resume();
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    if (!this.master || !this.ctx) return;
    this.master.gain.setTargetAtTime(muted ? 0 : this.volMaster, this.ctx.currentTime, 0.03);
  }

  /** Volumes de 0 a 1, vindos das configurações. */
  setVolumes(master: number, music: number, effects: number) {
    this.volMaster = master;
    this.volMusic = music;
    this.volEffects = effects;
    if (!this.ctx || !this.master || !this.music || !this.sfx) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(this.muted ? 0 : master, t, 0.03);
    this.music.gain.setTargetAtTime(0.45 * music, t, 0.03);
    this.sfx.gain.setTargetAtTime(0.7 * effects, t, 0.03);
  }

  tick() {
    if (!this.ctx || !this.music || this.muted) return;
    const notes = [196, 247, 294, 330, 392, 330, 294, 247];
    const t = this.ctx.currentTime;
    while (this.nextNote < t + 0.35) {
      this.tone(notes[this.noteIndex % notes.length] ?? 294, this.nextNote, 0.42, 0.045, this.music);
      this.noteIndex += 1;
      this.nextNote += 0.52;
    }
  }

  foot() {
    if (!this.ctx || !this.sfx || !this.noise || this.muted) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noise;
    src.playbackRate.value = 0.7 + Math.random() * 0.25;
    const filter = this.ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 240 + Math.random() * 80;
    const gain = this.ctx.createGain();
    const now = this.ctx.currentTime;
    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfx);
    src.start(now);
    src.stop(now + 0.1);
  }

  blip() {
    if (!this.ctx || !this.sfx) return;
    this.tone(620, this.ctx.currentTime, 0.08, 0.06, this.sfx);
  }

  jump() {
    if (!this.ctx || !this.sfx || this.muted) return;
    const now = this.ctx.currentTime;
    this.tone(392, now, 0.12, 0.05, this.sfx);
    this.tone(523, now + 0.06, 0.14, 0.05, this.sfx);
  }

  pick() {
    if (!this.ctx || !this.sfx || this.muted) return;
    const now = this.ctx.currentTime;
    this.tone(784, now, 0.08, 0.06, this.sfx);
    this.tone(1175, now + 0.05, 0.12, 0.06, this.sfx);
  }

  fail() {
    if (!this.ctx || !this.sfx || this.muted) return;
    const now = this.ctx.currentTime;
    this.tone(247, now, 0.2, 0.07, this.sfx);
    this.tone(196, now + 0.16, 0.3, 0.07, this.sfx);
  }

  chime() {
    if (!this.ctx || !this.sfx) return;
    const now = this.ctx.currentTime;
    this.tone(523, now, 0.22, 0.07, this.sfx);
    this.tone(659, now + 0.08, 0.24, 0.07, this.sfx);
    this.tone(784, now + 0.16, 0.32, 0.08, this.sfx);
  }

  private tone(freq: number, when: number, dur: number, volume: number, dest: GainNode) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(volume, when + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    osc.connect(gain);
    gain.connect(dest);
    osc.start(when);
    osc.stop(when + dur + 0.02);
  }
}
