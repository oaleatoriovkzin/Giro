import * as THREE from "three";
import { PLACES, RADIUS, type Place } from "@/game/content";

export function surfacePoint(lat: number, lon: number, radius = RADIUS) {
  const cl = Math.cos(lat);
  const sl = Math.sin(lat);
  return new THREE.Vector3(radius * cl * Math.sin(lon), radius * sl, radius * cl * Math.cos(lon));
}

export function surfaceInto(out: THREE.Vector3, lat: number, lon: number, radius = RADIUS) {
  const cl = Math.cos(lat);
  const sl = Math.sin(lat);
  return out.set(radius * cl * Math.sin(lon), radius * sl, radius * cl * Math.cos(lon));
}

export function eastTangent(lon: number) {
  return new THREE.Vector3(Math.cos(lon), 0, -Math.sin(lon)).normalize();
}

const _face = new THREE.Vector3();
const _x = new THREE.Vector3();
const _basis = new THREE.Matrix4();

export function orientUp(object: THREE.Object3D, up: THREE.Vector3, face: THREE.Vector3) {
  _face.copy(face).addScaledVector(up, -face.dot(up));
  if (_face.lengthSq() < 1e-6) _face.set(1, 0, 0);
  _face.normalize();
  _x.crossVectors(up, _face).normalize();
  _basis.makeBasis(_x, up, _face);
  object.quaternion.setFromRotationMatrix(_basis);
}

const ink = 0x2c241c;
const cream = 0xf6f1e6;
const pine = 0x2f6b5a;
const pineDeep = 0x214c40;
const coral = 0xe07a5f;
const sand = 0xe6d3a4;
const wood = 0x8c6239;

function lambert(color: number) {
  return new THREE.MeshLambertMaterial({ color });
}

function standard(color: number, roughness = 0.85) {
  return new THREE.MeshStandardMaterial({ color, roughness, metalness: 0 });
}

export type Rig = {
  root: THREE.Group;
  leftLeg: THREE.Object3D;
  rightLeg: THREE.Object3D;
  leftArm: THREE.Object3D;
  rightArm: THREE.Object3D;
};

export function buildCharacter(place: Pick<Place, "top" | "bottom" | "hat" | "scale">): Rig {
  const root = new THREE.Group();
  root.scale.setScalar(place.scale);

  const skin = standard(0xf0c7a4, 0.78);
  const hairMat = standard(0x3a2a22, 0.9);
  const topMat = standard(place.top, 0.85);
  const bottomMat = standard(place.bottom, 0.9);
  const shoeMat = standard(ink, 0.7);
  const hatMat = standard(place.hat === "beanie" ? pine : coral, 0.85);

  const hip = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 10), bottomMat);
  hip.position.y = 0.52;
  hip.scale.set(1.15, 0.7, 1);
  root.add(hip);

  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 0.28, 6, 12), topMat);
  torso.position.y = 0.92;
  root.add(torso);

  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 0.1, 10), skin);
  neck.position.y = 1.2;
  root.add(neck);

  // Cabeça: esfera de raio 0.2 centrada em y = 1.38. O rosto olha para +Z.
  // Tudo do rosto (olhos, nariz, boca) fica NA superfície da esfera, e o cabelo e o
  // chapéu só cobrem de cima para trás, nunca a frente do rosto.
  const HEAD_Y = 1.38;
  const HEAD_R = 0.2;
  const head = new THREE.Mesh(new THREE.SphereGeometry(HEAD_R, 24, 18), skin);
  head.position.y = HEAD_Y;
  root.add(head);

  const faceZ = (x: number, y: number, bulge = 0) =>
    Math.sqrt(Math.max(0, HEAD_R * HEAD_R - x * x - y * y)) + bulge;

  // Olhos: branco + pupila, na superfície, com brilho
  const eyeWhiteMat = standard(0xffffff, 0.4);
  const pupilMat = standard(ink, 0.3);
  for (const side of [-1, 1]) {
    const x = side * 0.072;
    const y = 0.025;
    const white = new THREE.Mesh(new THREE.SphereGeometry(0.036, 14, 12), eyeWhiteMat);
    white.scale.set(1, 1.1, 0.55);
    white.position.set(x, HEAD_Y + y, faceZ(x, y, -0.004));
    const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.02, 12, 10), pupilMat);
    pupil.position.set(x, HEAD_Y + y - 0.002, faceZ(x, y, 0.014));
    const brow = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.012, 0.012), hairMat);
    brow.position.set(x, HEAD_Y + y + 0.055, faceZ(x, y + 0.055, 0.004));
    brow.rotation.z = side * -0.12;
    root.add(white, pupil, brow);
  }

  // Nariz
  const nose = new THREE.Mesh(new THREE.SphereGeometry(0.022, 10, 8), standard(0xe3b08c, 0.8));
  nose.position.set(0, HEAD_Y - 0.012, faceZ(0, -0.012, 0.006));
  root.add(nose);

  // Boca: sorriso feito com um arco fino
  const mouth = new THREE.Mesh(
    new THREE.TorusGeometry(0.045, 0.0075, 6, 16, Math.PI),
    standard(0x9a4b3c, 0.7),
  );
  mouth.rotation.z = Math.PI;
  mouth.position.set(0, HEAD_Y - 0.052, faceZ(0, -0.052, 0.004));
  root.add(mouth);

  // Bochechas
  const cheekMat = standard(0xe9a08a, 0.9);
  for (const side of [-1, 1]) {
    const x = side * 0.115;
    const y = -0.035;
    const cheek = new THREE.Mesh(new THREE.SphereGeometry(0.02, 8, 6), cheekMat);
    cheek.scale.set(1, 0.7, 0.35);
    cheek.position.set(x, HEAD_Y + y, faceZ(x, y, 0.002));
    root.add(cheek);
  }

  // Orelhas
  for (const side of [-1, 1]) {
    const ear = new THREE.Mesh(new THREE.SphereGeometry(0.04, 10, 8), skin);
    ear.scale.set(0.5, 1, 0.8);
    ear.position.set(side * (HEAD_R + 0.005), HEAD_Y - 0.005, -0.005);
    root.add(ear);
  }

  // Cabelo: calota que cobre só do topo para trás (a frente do rosto fica livre)
  const hair = new THREE.Mesh(
    new THREE.SphereGeometry(HEAD_R + 0.012, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.42),
    hairMat,
  );
  hair.position.set(0, HEAD_Y + 0.006, -0.012);
  hair.rotation.x = -0.3;
  root.add(hair);
  const hairBack = new THREE.Mesh(
    new THREE.SphereGeometry(HEAD_R + 0.012, 20, 12, Math.PI * 1.05, Math.PI * 0.9, Math.PI * 0.3, Math.PI * 0.4),
    hairMat,
  );
  hairBack.position.set(0, HEAD_Y + 0.006, -0.012);
  root.add(hairBack);

  if (place.hat === "cap" || place.hat === "brim") {
    const cap = new THREE.Mesh(
      new THREE.SphereGeometry(HEAD_R + 0.03, 24, 14, 0, Math.PI * 2, 0, Math.PI * 0.42),
      hatMat,
    );
    cap.position.set(0, HEAD_Y + 0.02, -0.01);
    cap.rotation.x = -0.12;
    root.add(cap);
    // aba acima dos olhos, inclinada para cima
    const brim = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.016, 0.14), hatMat);
    brim.position.set(0, HEAD_Y + 0.115, HEAD_R + 0.04);
    brim.rotation.x = -0.18;
    root.add(brim);
  } else if (place.hat === "beanie") {
    const beanie = new THREE.Mesh(
      new THREE.SphereGeometry(HEAD_R + 0.03, 24, 14, 0, Math.PI * 2, 0, Math.PI * 0.4),
      hatMat,
    );
    beanie.position.set(0, HEAD_Y + 0.025, -0.008);
    beanie.rotation.x = -0.1;
    root.add(beanie);
    const bobble = new THREE.Mesh(new THREE.SphereGeometry(0.04, 10, 8), standard(cream, 0.9));
    bobble.position.set(0, HEAD_Y + HEAD_R + 0.045, -0.01);
    root.add(bobble);
  } else {
    // laço no alto da cabeça, de lado e sem cobrir o rosto
    const bowMat = standard(coral, 0.8);
    const bowL = new THREE.Mesh(new THREE.ConeGeometry(0.055, 0.1, 8), bowMat);
    bowL.rotation.z = Math.PI / 2;
    bowL.position.set(-0.055, HEAD_Y + HEAD_R + 0.025, -0.02);
    const bowR = bowL.clone();
    bowR.rotation.z = -Math.PI / 2;
    bowR.position.x = 0.055;
    const knot = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 6), bowMat);
    knot.position.set(0, HEAD_Y + HEAD_R + 0.025, -0.02);
    root.add(bowL, bowR, knot);
  }

  const satchel = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.16, 0.08), standard(coral, 0.8));
  satchel.position.set(-0.18, 0.9, -0.12);
  root.add(satchel);

  const legGeo = new THREE.CapsuleGeometry(0.07, 0.22, 4, 8);
  legGeo.translate(0, -0.18, 0);
  const leftLeg = new THREE.Group();
  const rightLeg = new THREE.Group();
  leftLeg.position.set(-0.1, 0.5, 0);
  rightLeg.position.set(0.1, 0.5, 0);
  const leftLegMesh = new THREE.Mesh(legGeo, bottomMat);
  const rightLegMesh = new THREE.Mesh(legGeo, bottomMat);
  const shoeGeo = new THREE.BoxGeometry(0.12, 0.06, 0.16);
  const shoeL = new THREE.Mesh(shoeGeo, shoeMat);
  const shoeR = new THREE.Mesh(shoeGeo, shoeMat);
  shoeL.position.set(0, -0.34, 0.03);
  shoeR.position.set(0, -0.34, 0.03);
  leftLeg.add(leftLegMesh, shoeL);
  rightLeg.add(rightLegMesh, shoeR);
  root.add(leftLeg, rightLeg);

  const armGeo = new THREE.CapsuleGeometry(0.055, 0.2, 4, 8);
  armGeo.translate(0, -0.16, 0);
  const leftArm = new THREE.Group();
  const rightArm = new THREE.Group();
  leftArm.position.set(-0.28, 1.12, 0);
  rightArm.position.set(0.28, 1.12, 0);
  leftArm.add(new THREE.Mesh(armGeo, topMat));
  rightArm.add(new THREE.Mesh(armGeo, skin));
  root.add(leftArm, rightArm);

  root.traverse((obj) => {
    if (obj instanceof THREE.Mesh) obj.castShadow = true;
  });

  return { root, leftLeg, rightLeg, leftArm, rightArm };
}

function addHouse(parent: THREE.Object3D, place: Place) {
  const pos = surfacePoint(place.lat, place.lon);
  const up = pos.clone().normalize();
  const face = eastTangent(place.lon);
  const group = new THREE.Group();
  group.position.copy(pos);
  orientUp(group, up, face);

  const wall = lambert(cream);
  const roof = lambert(coral);
  const trim = lambert(wood);

  if (place.kind === "light") {
    const tower = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.7, 3.2, 8), wall);
    tower.position.y = 1.6;
    const lamp = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.55, 8), lambert(0xf6e27a));
    lamp.position.y = 3.4;
    const cap = new THREE.Mesh(new THREE.ConeGeometry(0.7, 0.55, 8), lambert(pineDeep));
    cap.position.y = 3.9;
    group.add(tower, lamp, cap);
  } else if (place.kind === "school") {
    const body = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.3, 1.5), wall);
    body.position.y = 0.7;
    const top = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.28, 1.7), lambert(0x3d7ea6));
    top.position.y = 1.45;
    const door = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.7, 0.08), trim);
    door.position.set(0, 0.4, 0.76);
    group.add(body, top, door);
  } else if (place.kind === "shop") {
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.7, 1.15, 1.4), lambert(0xd7c4a3));
    body.position.y = 0.6;
    const roofMesh = new THREE.Mesh(new THREE.ConeGeometry(1.25, 0.7, 4), lambert(ink));
    roofMesh.position.y = 1.45;
    roofMesh.rotation.y = Math.PI / 4;
    const chimney = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.45, 0.22), lambert(coral));
    chimney.position.set(0.4, 1.7, -0.2);
    group.add(body, roofMesh, chimney);
  } else if (place.kind === "park") {
    const bench = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.1, 0.36), trim);
    bench.position.set(0, 0.45, 0);
    const legL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.4, 0.3), trim);
    const legR = legL.clone();
    legL.position.set(-0.42, 0.2, 0);
    legR.position.set(0.42, 0.2, 0);
    group.add(bench, legL, legR);
  } else {
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.35, 1.05, 1.2), place.kind === "post" ? lambert(0xf7f3ea) : wall);
    body.position.y = 0.55;
    const roofMesh = new THREE.Mesh(new THREE.ConeGeometry(1.05, 0.7, 4), place.kind === "post" ? lambert(pine) : roof);
    roofMesh.position.y = 1.35;
    roofMesh.rotation.y = Math.PI / 4;
    const door = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.55, 0.08), trim);
    door.position.set(0, 0.32, 0.62);
    group.add(body, roofMesh, door);
    if (place.kind === "post") {
      const box = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.34, 0.22), lambert(coral));
      box.position.set(0.7, 0.28, 0.4);
      group.add(box);
    }
  }

  if (place.kind === "garden") {
    for (let i = 0; i < 4; i += 1) {
      const plant = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.45, 5), lambert(pine));
      plant.position.set(-0.7 + i * 0.45, 0.25, 0.9);
      group.add(plant);
    }
  }

  group.traverse((obj) => {
    if (obj instanceof THREE.Mesh) {
      obj.castShadow = true;
      obj.receiveShadow = true;
    }
  });
  parent.add(group);
  return pos;
}

function hash(n: number) {
  const x = Math.sin(n * 127.1) * 43758.5453;
  return x - Math.floor(x);
}

function fbm(x: number, y: number, z: number) {
  return (
    Math.sin(x * 0.55) * 0.5 +
    Math.sin(y * 0.9 + 1.7) * 0.28 +
    Math.sin(z * 0.37 + x * 0.21) * 0.32
  );
}

export type NpcActor = {
  id: Place["id"];
  name: string;
  place: string;
  pos: THREE.Vector3;
  rig: Rig;
};

export type World = {
  player: Rig;
  npcs: NpcActor[];
  guide: THREE.Mesh;
  updateEnvironment: (cycle: number, focus?: THREE.Vector3) => void;
  dispose: () => void;
};

export function buildWorld(scene: THREE.Scene): World {
  const disposables: Array<{ dispose: () => void }> = [];
  const track = <T extends { dispose: () => void }>(item: T) => {
    disposables.push(item);
    return item;
  };

  const grassA = new THREE.Color("#6eae62");
  const grassB = new THREE.Color("#4e9458");
  const sandC = new THREE.Color("#e4d2a4");
  const water = new THREE.Color("#3e8eab");
  const rock = new THREE.Color("#8d9074");

  const planetGeo = track(new THREE.SphereGeometry(RADIUS, 80, 56));
  const position = planetGeo.attributes.position;
  const colors = new Float32Array(position.count * 3);
  const color = new THREE.Color();
  for (let i = 0; i < position.count; i += 1) {
    const x = position.getX(i);
    const y = position.getY(i);
    const z = position.getZ(i);
    const n = fbm(x, y, z);
    if (n < -0.42) {
      color.copy(water);
      const len = Math.hypot(x, y, z) || 1;
      const sink = 0.97;
      position.setXYZ(i, (x / len) * RADIUS * sink, (y / len) * RADIUS * sink, (z / len) * RADIUS * sink);
    } else if (n < -0.22) color.copy(sandC);
    else if (n > 0.55) color.copy(rock);
    else color.copy(hash(i + n) > 0.5 ? grassA : grassB);
    colors[i * 3] = color.r;
    colors[i * 3 + 1] = color.g;
    colors[i * 3 + 2] = color.b;
  }
  planetGeo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
  planetGeo.computeVertexNormals();
  const planetMat = track(new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.96, metalness: 0 }));
  const planet = new THREE.Mesh(planetGeo, planetMat);
  planet.receiveShadow = true;
  scene.add(planet);

  const skyGeo = track(new THREE.SphereGeometry(90, 20, 16));
  const skyPos = skyGeo.attributes.position;
  const skyColors = new Float32Array(skyPos.count * 3);
  const top = new THREE.Color("#8ecae6");
  const mid = new THREE.Color("#d7efe8");
  const horizon = new THREE.Color("#f6e7c8");
  for (let i = 0; i < skyPos.count; i += 1) {
    const y = skyPos.getY(i) / 90;
    color.copy(horizon).lerp(mid, THREE.MathUtils.clamp((y + 0.2) * 1.4, 0, 1));
    color.lerp(top, THREE.MathUtils.clamp(y, 0, 1));
    skyColors[i * 3] = color.r;
    skyColors[i * 3 + 1] = color.g;
    skyColors[i * 3 + 2] = color.b;
  }
  skyGeo.setAttribute("color", new THREE.BufferAttribute(skyColors, 3));
  const skyMat = track(new THREE.MeshBasicMaterial({ vertexColors: true, color: 0xffffff, side: THREE.BackSide, depthWrite: false }));
  scene.add(new THREE.Mesh(skyGeo, skyMat));

  // Fine grass blades add texture close to the camera without creating thousands of draw calls.
  const grassGeo = track(new THREE.ConeGeometry(0.035, 0.28, 3));
  grassGeo.translate(0, 0.14, 0);
  const grassMat = track(new THREE.MeshStandardMaterial({ color: 0x8fca69, roughness: 1 }));
  const grass = new THREE.InstancedMesh(grassGeo, grassMat, 1900);
  grass.frustumCulled = false;
  const grassColors = [new THREE.Color(0x7eb85d), new THREE.Color(0x9bcf70), new THREE.Color(0x5f9d4e), new THREE.Color(0xb0d77a)];
  const grassUp = new THREE.Vector3();
  const grassDummy = new THREE.Object3D();
  let grassCount = 0;
  for (let i = 0; i < 5200 && grassCount < 1900; i += 1) {
    const lat = (hash(i * 17.13 + 2) - 0.5) * 2.2;
    const lon = hash(i * 29.71 + 4) * Math.PI * 2;
    const n = fbm(RADIUS * Math.cos(lat) * Math.sin(lon), RADIUS * Math.sin(lat), RADIUS * Math.cos(lat) * Math.cos(lon));
    if (n < -0.18 || n > 0.52) continue;
    if (PLACES.some((place) => Math.hypot(place.lat - lat, Math.atan2(Math.sin(place.lon - lon), Math.cos(place.lon - lon))) < 0.075)) continue;
    const point = surfacePoint(lat, lon, RADIUS + 0.012);
    grassUp.copy(point).normalize();
    grassDummy.position.copy(point);
    grassDummy.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), grassUp);
    grassDummy.rotateY(hash(i * 3.7) * Math.PI * 2);
    const scale = 0.65 + hash(i * 5.9) * 0.9;
    grassDummy.scale.set(scale, scale, scale);
    grassDummy.updateMatrix();
    grass.setMatrixAt(grassCount, grassDummy.matrix);
    grass.setColorAt(grassCount, grassColors[Math.floor(hash(i * 11.3) * grassColors.length)]);
    grassCount += 1;
  }
  grass.count = grassCount;
  scene.add(grass);

  const treeMat = track(lambert(pine));
  const trunkMat = track(lambert(wood));
  const treeGeo = track(new THREE.ConeGeometry(0.38, 1.25, 6));
  treeGeo.translate(0, 1.05, 0);
  const trunkGeo = track(new THREE.CylinderGeometry(0.08, 0.1, 0.4, 5));
  trunkGeo.translate(0, 0.2, 0);
  const trees = new THREE.InstancedMesh(treeGeo, treeMat, 42);
  const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, 42);
  const dummy = new THREE.Object3D();
  let planted = 0;
  for (let i = 0; i < 80 && planted < 42; i += 1) {
    const lat = (hash(i * 3.1) - 0.5) * 1.5;
    const lon = hash(i * 9.7) * Math.PI * 2;
    if (PLACES.some((p) => Math.hypot(p.lat - lat, Math.atan2(Math.sin(p.lon - lon), Math.cos(p.lon - lon))) < 0.28)) {
      continue;
    }
    const p = surfacePoint(lat, lon);
    const up = p.clone().normalize();
    dummy.position.copy(p);
    dummy.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), up);
    const s = 0.8 + hash(i + 4) * 0.7;
    dummy.scale.setScalar(s);
    dummy.updateMatrix();
    trees.setMatrixAt(planted, dummy.matrix);
    dummy.scale.setScalar(s);
    dummy.position.addScaledVector(up, 0.05);
    dummy.updateMatrix();
    trunks.setMatrixAt(planted, dummy.matrix);
    planted += 1;
  }
  trees.count = planted;
  trunks.count = planted;
  trees.castShadow = true;
  trunks.castShadow = true;
  scene.add(trees, trunks);

  const clouds = new THREE.Group();
  const cloudMat = track(new THREE.MeshLambertMaterial({ color: 0xffffff, transparent: true, opacity: 0.88 }));
  for (let i = 0; i < 7; i += 1) {
    const puff = new THREE.Mesh(track(new THREE.SphereGeometry(1, 10, 8)), cloudMat);
    puff.position.copy(surfacePoint((hash(i + 2) - 0.5) * 0.8, hash(i + 5) * Math.PI * 2, 24 + hash(i) * 3));
    puff.scale.set(1.8 + hash(i + 1), 0.55, 1.1);
    clouds.add(puff);
  }
  scene.add(clouds);
  clouds.name = "clouds";

  const npcs: NpcActor[] = [];
  for (const place of PLACES) {
    addHouse(scene, place);
    const standLon = place.lon + 1.8 / RADIUS;
    const pos = surfacePoint(place.lat, standLon);
    const rig = buildCharacter(place);
    rig.root.position.copy(pos);
    orientUp(rig.root, pos.clone().normalize(), eastTangent(standLon));
    scene.add(rig.root);
    const label = makeLabel(place.name);
    label.position.y = 2.15;
    rig.root.add(label);
    npcs.push({ id: place.id, name: place.name, place: place.place, pos, rig });
  }

  const player = buildCharacter({
    top: pine,
    bottom: 0x24362f,
    hat: "cap",
    scale: 1,
  });
  scene.add(player.root);

  const guide = new THREE.Mesh(track(new THREE.ConeGeometry(0.16, 0.42, 5)), track(lambert(coral)));
  scene.add(guide);

  const hemi = new THREE.HemisphereLight(0xfff6ea, 0x6eae62, 1.2);
  const sun = new THREE.DirectionalLight(0xfff0d0, 2.0);
  sun.position.set(40, 55, 20);
  sun.castShadow = true;
  const smallScreen = window.innerWidth < 760;
  sun.shadow.mapSize.set(smallScreen ? 1024 : 2048, smallScreen ? 1024 : 2048);
  // A câmera de sombra é pequena e acompanha o jogador, então a sombra fica nítida perto dele.
  sun.shadow.camera.left = -14;
  sun.shadow.camera.right = 14;
  sun.shadow.camera.top = 14;
  sun.shadow.camera.bottom = -14;
  sun.shadow.camera.near = 1;
  sun.shadow.camera.far = 120;
  sun.shadow.bias = -0.0004;
  sun.shadow.normalBias = 0.03;
  scene.add(sun.target);
  const fill = new THREE.DirectionalLight(0x9fd4ea, 0.38);
  fill.position.set(-30, 12, -16);
  scene.add(hemi, sun, fill);

  const starPositions = new Float32Array(420 * 3);
  for (let i = 0; i < 420; i += 1) {
    const y = hash(i * 13.3 + 1) * 2 - 1;
    const angle = hash(i * 19.7 + 2) * Math.PI * 2;
    const radius = Math.sqrt(1 - y * y);
    starPositions[i * 3] = Math.cos(angle) * radius * 84;
    starPositions[i * 3 + 1] = y * 84;
    starPositions[i * 3 + 2] = Math.sin(angle) * radius * 84;
  }
  const starGeo = track(new THREE.BufferGeometry());
  starGeo.setAttribute("position", new THREE.BufferAttribute(starPositions, 3));
  const starMat = track(new THREE.PointsMaterial({ color: 0xf7f2db, size: 0.34, sizeAttenuation: true, transparent: true, opacity: 0, depthWrite: false }));
  const stars = new THREE.Points(starGeo, starMat);
  scene.add(stars);
  const moonMat = track(new THREE.MeshBasicMaterial({ color: 0xf6f0d6 }));
  const moon = new THREE.Mesh(track(new THREE.SphereGeometry(1.8, 18, 14)), moonMat);
  moon.position.set(-38, 28, -48);
  scene.add(moon);

  scene.fog = new THREE.Fog(0xc5e4ef, 18, 52);

  const daySky = new THREE.Color(0xffffff);
  const nightSky = new THREE.Color(0x52658f);
  const dayFog = new THREE.Color(0xc5e4ef);
  const nightFog = new THREE.Color(0x1d2947);
  const dayHemi = 1.2;
  const daySun = 2.0;
  const dayFill = 0.38;
  const dayFogColor = new THREE.Color();
  const daySkyColor = new THREE.Color();
  const duskSky = new THREE.Color(0xf0a77d);
  const duskFog = new THREE.Color(0xd99b80);
  const sunDir = new THREE.Vector3();
  const dayCycleUpdate = (cycle: number, focus?: THREE.Vector3) => {
    // cycle is 0..1: sunrise, noon, sunset, night. Keep a long, gentle transition.
    const sunHeight = Math.sin(cycle * Math.PI * 2 - Math.PI / 2);
    const daylight = THREE.MathUtils.smoothstep(sunHeight, -0.22, 0.32);
    const dusk = Math.max(0, 1 - Math.abs(sunHeight) * 4) * (1 - daylight);
    daySkyColor.copy(nightSky).lerp(daySky, daylight).lerp(new THREE.Color(0xf0a77d), dusk * 0.5);
    dayFogColor.copy(nightFog).lerp(dayFog, daylight).lerp(new THREE.Color(0xd99b80), dusk * 0.36);
    skyMat.color.copy(daySkyColor);
    scene.fog?.color.copy(dayFogColor);
    hemi.intensity = 0.22 + daylight * dayHemi;
    sun.intensity = 0.06 + daylight * daySun;
    fill.intensity = 0.12 + daylight * dayFill;
    sun.color.setRGB(1, 0.78 + daylight * 0.16, 0.62 + daylight * 0.32);
    sunDir.set(Math.cos(cycle * Math.PI * 2) * 48, sunHeight * 55 + 5, Math.sin(cycle * Math.PI * 2) * 48).normalize();
    if (focus) {
      sun.target.position.copy(focus);
      sun.position.copy(focus).addScaledVector(sunDir, 60);
    } else {
      sun.target.position.set(0, 0, 0);
      sun.position.copy(sunDir).multiplyScalar(60);
    }
    sun.target.updateMatrixWorld();
    stars.material.opacity = THREE.MathUtils.clamp((1 - daylight) * 1.15, 0, 0.92);
    moon.visible = daylight < 0.48;
    moon.material.opacity = THREE.MathUtils.clamp((0.48 - daylight) * 2.6, 0, 1);
    (moon.material as THREE.MeshBasicMaterial).transparent = true;
    grassMat.color.setRGB(0.72 + daylight * 0.28, 0.78 + daylight * 0.22, 0.72 + daylight * 0.28);
  };
  dayCycleUpdate(0.32);

  return {
    player,
    npcs,
    guide,
    updateEnvironment: dayCycleUpdate,
    dispose: () => {
      const geometries = new Set<THREE.BufferGeometry>();
      const materials = new Set<THREE.Material>();
      scene.traverse((obj) => {
        if (obj instanceof THREE.Mesh) {
          geometries.add(obj.geometry);
          const mat = obj.material;
          if (Array.isArray(mat)) mat.forEach((item) => materials.add(item));
          else materials.add(mat);
        }
        if (obj instanceof THREE.Points) {
          geometries.add(obj.geometry);
          const mat = obj.material;
          if (Array.isArray(mat)) mat.forEach((item) => materials.add(item));
          else materials.add(mat);
        }
        if (obj instanceof THREE.Sprite) {
          obj.material.map?.dispose();
          materials.add(obj.material);
        }
      });
      geometries.forEach((geo) => geo.dispose());
      materials.forEach((mat) => mat.dispose());
      scene.clear();
    },
  };
}

export function makeLabel(text: string) {
  const canvas = document.createElement("canvas");
  canvas.width = 256;
  canvas.height = 72;
  const ctx = canvas.getContext("2d");
  if (!ctx) return new THREE.Sprite();
  ctx.fillStyle = "rgba(246,241,230,0.94)";
  roundRect(ctx, 16, 8, 224, 56, 28);
  ctx.fill();
  ctx.fillStyle = "#2c241c";
  ctx.font = "700 32px Nunito, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, 128, 38);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const material = new THREE.SpriteMaterial({ map: texture, transparent: true, depthWrite: false });
  const sprite = new THREE.Sprite(material);
  sprite.scale.set(1.7, 0.48, 1);
  sprite.position.y = 2.15;
  return sprite;
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

export const cloudsSpin = { groupName: "clouds" };
