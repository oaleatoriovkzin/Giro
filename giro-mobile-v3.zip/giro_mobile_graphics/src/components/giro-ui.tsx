import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  ChevronUp,
  Compass,
  Footprints,
  Minus,
  Pause,
  Plus,
  RotateCcw,
  Users,
  Volume2,
  VolumeX,
  Wifi,
  X,
} from "lucide-react";
import { GiroMenu } from "@/components/giro-menu";
import { gameApi } from "@/game/api";
import { QUEST } from "@/game/content";
import { input } from "@/game/engine";
import { formatTime, objectiveOf, onHudTick, useGiro } from "@/game/store";

export function GiroOverlay() {
  const screen = useGiro((s) => s.screen);
  const helpOpen = useGiro((s) => s.helpOpen);

  return (
    <div className="pointer-events-none absolute inset-0">
      {screen === "title" ? <GiroMenu /> : null}
      {screen === "play" || screen === "dialog" ? <PlayChrome /> : null}
      {screen === "dialog" ? <DialogCard /> : null}
      {screen === "pause" ? <PauseCard /> : null}
      {screen === "done" ? <DoneCard /> : null}
      {helpOpen ? <HelpCard /> : null}
    </div>
  );
}

function SettingsForm() {
  const sensitivity = useGiro((s) => s.sensitivity);
  const camDist = useGiro((s) => s.camDist);
  const invert = useGiro((s) => s.invert);
  const muted = useGiro((s) => s.muted);
  const padStyle = useGiro((s) => s.padStyle);
  const setSensitivity = useGiro((s) => s.setSensitivity);
  const setCamDist = useGiro((s) => s.setCamDist);
  const setInvert = useGiro((s) => s.setInvert);
  const setMuted = useGiro((s) => s.setMuted);
  const setPadStyle = useGiro((s) => s.setPadStyle);

  return (
    <div className="mt-2 space-y-3 rounded-2xl border border-line p-3">
      <div>
        <p className="text-sm font-bold">Botões de andar</p>
        <div className="mt-1 grid grid-cols-2 gap-1 rounded-full bg-line p-1">
          <button
            type="button"
            className={padStyle === "stick" ? "h-10 rounded-full bg-paper font-extrabold text-ink" : "h-10 rounded-full font-bold text-muted"}
            onClick={() => setPadStyle("stick")}
          >
            Joystick
          </button>
          <button
            type="button"
            className={padStyle === "buttons" ? "h-10 rounded-full bg-paper font-extrabold text-ink" : "h-10 rounded-full font-bold text-muted"}
            onClick={() => setPadStyle("buttons")}
          >
            Setas
          </button>
        </div>
      </div>
      <label className="block text-sm font-bold">
        Sensibilidade da curva
        <input
          className="giro-range mt-1"
          type="range"
          min={0.6}
          max={1.6}
          step={0.05}
          value={sensitivity}
          onChange={(event) => setSensitivity(Number(event.target.value))}
        />
      </label>
      <label className="block text-sm font-bold">
        Distância da câmera
        <input
          className="giro-range mt-1"
          type="range"
          min={4.2}
          max={9}
          step={0.1}
          value={camDist}
          onChange={(event) => setCamDist(Number(event.target.value))}
        />
      </label>
      <button type="button" className="h-11 w-full rounded-full bg-line font-bold" onClick={() => setInvert(!invert)}>
        {invert ? "Esquerda e direita invertidas" : "Virar no sentido normal"}
      </button>
      <button type="button" className="inline-flex h-11 items-center gap-2 font-bold" onClick={() => setMuted(!muted)}>
        {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
        {muted ? "Som desligado" : "Som ligado"}
      </button>
    </div>
  );
}

function PlayChrome() {
  const step = useGiro((s) => s.step);
  const near = useGiro((s) => s.near);
  const nearName = useGiro((s) => s.nearName);
  const banner = useGiro((s) => s.banner);
  const mode = useGiro((s) => s.mode);
  const padStyle = useGiro((s) => s.padStyle);
  const gameType = useGiro((s) => s.gameType);
  const controlMode = useGiro((s) => s.settings.controlMode);
  const chInfo = useGiro((s) => s.chInfo);
  const story = gameType === "story";
  const carrying = QUEST[step]?.carrying ?? null;
  const distRef = useRef<HTMLSpanElement>(null);
  const timeRef = useRef<HTMLSpanElement>(null);
  const blipRef = useRef<HTMLSpanElement>(null);
  const [routeOpen, setRouteOpen] = useState(false);

  useEffect(() => {
    return onHudTick((tick) => {
      if (distRef.current) distRef.current.textContent = `${Math.max(0, Math.round(tick.meters))} m`;
      if (timeRef.current) timeRef.current.textContent = formatTime(tick.elapsed);
      if (blipRef.current) {
        blipRef.current.style.transform = `rotate(${(-tick.bearing * 180) / Math.PI}deg)`;
      }
    });
  }, []);

  // Se o painel sair da tela com um botão apertado, solta tudo.
  useEffect(() => {
    return () => {
      releaseTouchInput();
    };
  }, []);

  return (
    <>
      <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-2 p-3 sm:p-4">
        {story ? (
        <div className="pointer-events-auto max-w-[70%] rounded-3xl bg-paper/95 px-4 py-3 text-ink shadow-card">
          <p className="text-xs font-extrabold tracking-wide text-pine uppercase">
            {Math.min(step + 1, QUEST.length)} de {QUEST.length}
          </p>
          <p className="text-sm leading-snug font-extrabold sm:text-base">{objectiveOf(step)}</p>
          <div className="mt-1 flex items-center gap-3 text-xs font-bold text-muted">
            <span className="inline-flex items-center gap-1">
              <Compass className="size-3.5" aria-hidden="true" />
              <span ref={distRef}>—</span>
            </span>
            <span ref={timeRef}>0:00</span>
            {carrying ? <span className="text-coral-deep">Bolsa: {carrying}</span> : null}
          </div>
        </div>
        ) : (
          <ChallengeCard />
        )}
        <div className="pointer-events-auto flex gap-2">
          {story ? (
            <button
              type="button"
              className="grid size-12 place-items-center rounded-full bg-paper text-ink shadow-card"
              aria-label="Rota"
              onClick={() => setRouteOpen((v) => !v)}
            >
              <Footprints className="size-5" />
            </button>
          ) : null}
          <button
            type="button"
            className="grid size-12 place-items-center rounded-full bg-paper text-ink shadow-card"
            aria-label="Pausar"
            onClick={() => gameApi()?.pause()}
          >
            <Pause className="size-5" />
          </button>
        </div>
      </div>

      {mode === "multi" ? <OnlineChip /> : null}

      {!story && chInfo && (chInfo.phase === "prep" || chInfo.phase === "fail") ? <ChallengeIntro /> : null}

      <div className="pointer-events-none absolute top-24 right-4 hidden size-16 rounded-full border-4 border-paper/80 lg:block" aria-hidden="true">
        <span ref={blipRef} className="absolute inset-0">
          <span className="absolute top-1 left-1/2 size-3 -translate-x-1/2 rounded-full bg-coral" />
        </span>
      </div>

      {banner ? (
        <p className="pointer-events-none absolute top-28 left-1/2 -translate-x-1/2 rounded-full bg-pine px-4 py-2 text-sm font-extrabold text-paper">
          {banner}
        </p>
      ) : null}

      {routeOpen ? (
        <ol className="pointer-events-auto absolute top-20 left-3 max-h-[50dvh] w-56 overflow-y-auto rounded-3xl bg-paper p-3 text-sm shadow-card">
          {QUEST.map((quest, index) => {
            const state = index < step ? "feito" : index === step ? "agora" : "depois";
            return (
              <li key={`${quest.npc}-${index}`} className={state === "agora" ? "font-extrabold text-ink" : "text-muted"}>
                {index + 1}. {quest.objective}
                {state === "feito" ? " · feito" : ""}
              </li>
            );
          })}
        </ol>
      ) : null}

      {controlMode === "touch" ? (
      <div className="pointer-events-none absolute inset-x-0 bottom-0 safe-bottom flex items-end justify-between gap-3 p-4">
        {padStyle === "buttons" ? <DPad /> : <Joystick />}
        <div className="pointer-events-auto flex flex-col items-end gap-2">
          {near ? (
            <button
              type="button"
              className="h-14 rounded-full bg-coral px-6 text-base font-extrabold text-paper shadow-card"
              onClick={() => gameApi()?.interact()}
            >
              Falar com {nearName}
            </button>
          ) : (
            <p className="hidden rounded-full bg-paper/90 px-3 py-2 text-xs font-bold text-muted lg:block">
              Arraste para olhar · Espaço pula · C centraliza a câmera
            </p>
          )}
          <div className="flex items-center gap-2">
            <HoldButton
              label="Correr"
              className="grid h-14 w-16 place-items-center rounded-full bg-paper text-xs font-extrabold text-ink shadow-card"
              onDown={() => {
                input.sprint = true;
              }}
              onUp={() => {
                input.sprint = false;
              }}
            >
              Correr
            </HoldButton>
            <HoldButton
              label="Pular"
              className="grid size-16 place-items-center rounded-full bg-coral text-sm font-extrabold text-paper shadow-card active:scale-95"
              onDown={() => gameApi()?.jump()}
              onUp={() => undefined}
            >
              <span className="flex flex-col items-center leading-none">
                <ChevronUp className="size-5" aria-hidden="true" />
                Pular
              </span>
            </HoldButton>
          </div>
          <CameraPad />
        </div>
      </div>
      ) : near ? (
        <div className="pointer-events-none absolute inset-x-0 bottom-0 safe-bottom flex justify-end p-4">
          <button
            type="button"
            className="pointer-events-auto h-14 rounded-full bg-coral px-6 text-base font-extrabold text-paper shadow-card"
            onClick={() => gameApi()?.interact()}
          >
            Falar com {nearName}
          </button>
        </div>
      ) : null}
    </>
  );
}

function ChallengeCard() {
  const info = useGiro((s) => s.chInfo);
  const peers = useGiro((s) => s.peers);
  const mode = useGiro((s) => s.mode);
  const connected = peers.filter((p) => p.state === "connected").length;

  return (
    <div className="pointer-events-auto max-w-[70%] rounded-3xl bg-paper/95 px-4 py-3 text-ink shadow-card">
      <p className="text-xs font-extrabold tracking-wide text-pine uppercase">
        {info ? `Missão ${Math.min(info.index + 1, info.total)} de ${info.total}` : "Desafios"}
        {mode === "multi" ? ` · ${connected + 1} jogando` : ""}
      </p>
      <p className="text-sm leading-snug font-extrabold sm:text-base">{info?.title ?? "Preparando…"}</p>
      <div className="mt-1 flex flex-wrap items-center gap-x-3 text-xs font-bold text-muted">
        {info?.progress ? <span className="text-ink">{info.progress}</span> : null}
        {info?.time ? <span>{info.time}</span> : null}
      </div>
    </div>
  );
}

function ChallengeIntro() {
  const info = useGiro((s) => s.chInfo);
  if (!info) return null;
  return (
    <div className="pointer-events-none absolute inset-x-0 top-28 flex justify-center px-4">
      <section className="w-full max-w-sm rounded-3xl bg-paper/95 p-4 text-center text-ink shadow-card">
        <p className="text-xs font-extrabold tracking-wide text-coral-deep uppercase">{info.msg}</p>
        <h2 className="font-display mt-1 text-2xl font-bold">{info.title}</h2>
        <p className="mt-1 text-sm leading-relaxed text-muted">{info.hint}</p>
      </section>
    </div>
  );
}

/** Solta qualquer botão de toque que ficou apertado. */
function releaseTouchInput() {
  input.stickX = 0;
  input.stickY = 0;
  input.sprint = false;
  input.camYaw = 0;
  input.camPitch = 0;
  dpad.up = false;
  dpad.down = false;
  dpad.left = false;
  dpad.right = false;
}

type HoldButtonProps = {
  label: string;
  className: string;
  onDown: () => void;
  onUp: () => void;
  children: ReactNode;
};

/** Botão que vale enquanto o dedo estiver em cima (e solta se o toque for cancelado). */
function HoldButton({ label, className, onDown, onUp, children }: HoldButtonProps) {
  const held = useRef(false);

  function release() {
    if (!held.current) return;
    held.current = false;
    onUp();
  }

  return (
    <button
      type="button"
      aria-label={label}
      className={`${className} touch-none select-none`}
      onPointerDown={(event) => {
        event.preventDefault();
        event.currentTarget.setPointerCapture(event.pointerId);
        held.current = true;
        onDown();
      }}
      onPointerUp={release}
      onPointerCancel={release}
      onLostPointerCapture={release}
      onContextMenu={(event) => event.preventDefault()}
    >
      {children}
    </button>
  );
}

const dpad = { up: false, down: false, left: false, right: false };

function applyDpad() {
  input.stickY = (dpad.up ? 1 : 0) - (dpad.down ? 1 : 0);
  input.stickX = (dpad.right ? 1 : 0) - (dpad.left ? 1 : 0);
}

function DPad() {
  const base = "grid size-11 place-items-center rounded-full bg-paper/90 text-ink shadow-card active:bg-pine active:text-paper";
  const hold = (key: keyof typeof dpad, label: string, icon: ReactNode) => (
    <HoldButton
      label={label}
      className={base}
      onDown={() => {
        dpad[key] = true;
        applyDpad();
      }}
      onUp={() => {
        dpad[key] = false;
        applyDpad();
      }}
    >
      {icon}
    </HoldButton>
  );

  return (
    <div className="pointer-events-auto grid grid-cols-3 gap-1" role="group" aria-label="Andar">
      <span />
      {hold("up", "Andar para frente", <ArrowUp className="size-5" />)}
      <span />
      {hold("left", "Virar para a esquerda", <ArrowLeft className="size-5" />)}
      <span />
      {hold("right", "Virar para a direita", <ArrowRight className="size-5" />)}
      <span />
      {hold("down", "Andar para trás", <ArrowDown className="size-5" />)}
      <span />
    </div>
  );
}

function CameraPad() {
  const base = "grid size-9 place-items-center rounded-full bg-paper/90 text-ink shadow-card active:bg-pine active:text-paper";

  return (
    <div className="grid grid-cols-3 gap-1" role="group" aria-label="Câmera">
      <button type="button" aria-label="Aproximar a câmera" className={base} onClick={() => gameApi()?.zoom(-0.8)}>
        <Plus className="size-4" />
      </button>
      <HoldButton
        label="Subir a câmera"
        className={base}
        onDown={() => {
          input.camPitch = 1;
        }}
        onUp={() => {
          input.camPitch = 0;
        }}
      >
        <ArrowUp className="size-4" />
      </HoldButton>
      <button type="button" aria-label="Afastar a câmera" className={base} onClick={() => gameApi()?.zoom(0.8)}>
        <Minus className="size-4" />
      </button>
      <HoldButton
        label="Girar a câmera para a esquerda"
        className={base}
        onDown={() => {
          input.camYaw = 1;
        }}
        onUp={() => {
          input.camYaw = 0;
        }}
      >
        <ArrowLeft className="size-4" />
      </HoldButton>
      <button type="button" aria-label="Centralizar a câmera" className={base} onClick={() => gameApi()?.centerCamera()}>
        <Compass className="size-4" />
      </button>
      <HoldButton
        label="Girar a câmera para a direita"
        className={base}
        onDown={() => {
          input.camYaw = -1;
        }}
        onUp={() => {
          input.camYaw = 0;
        }}
      >
        <ArrowRight className="size-4" />
      </HoldButton>
      <span />
      <HoldButton
        label="Descer a câmera"
        className={base}
        onDown={() => {
          input.camPitch = -1;
        }}
        onUp={() => {
          input.camPitch = 0;
        }}
      >
        <ArrowDown className="size-4" />
      </HoldButton>
      <span />
    </div>
  );
}

function stateLabel(state: string) {
  if (state === "connected") return "conectado";
  if (state === "failed") return "não conectou (rede restrita)";
  if (state === "disconnected" || state === "closed") return "saiu";
  return "conectando…";
}

function OnlineChip() {
  const netStatus = useGiro((s) => s.netStatus);
  const room = useGiro((s) => s.room);
  const peers = useGiro((s) => s.peers);
  const [open, setOpen] = useState(false);
  const connected = peers.filter((p) => p.state === "connected").length;
  const roomName = room.startsWith("u-") ? `@${room.slice(2)}` : room;

  return (
    <div className="pointer-events-auto absolute top-[76px] right-3 flex max-w-[16rem] flex-col items-end gap-1 sm:right-4">
      <button
        type="button"
        className="inline-flex h-9 items-center gap-2 rounded-full bg-paper/95 px-3 text-xs font-extrabold text-ink shadow-card"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
      >
        {netStatus === "online" ? <Wifi className="size-4 text-pine" aria-hidden="true" /> : <Wifi className="size-4 text-muted" aria-hidden="true" />}
        <span className="truncate">{netStatus === "connecting" ? "Conectando…" : roomName}</span>
        <span className="inline-flex items-center gap-1 text-muted">
          <Users className="size-3.5" aria-hidden="true" />
          {connected + 1}
        </span>
      </button>
      {open ? (
        <div className="w-60 rounded-3xl bg-paper p-3 text-sm text-ink shadow-card">
          <p className="text-xs font-extrabold tracking-wide text-pine uppercase">Sala {roomName}</p>
          {peers.length === 0 ? (
            <p className="mt-1 text-muted">Ninguém mais por aqui ainda. Peça para um amigo entrar com o seu username.</p>
          ) : (
            <ul className="mt-1 space-y-1">
              {peers.map((peer) => (
                <li key={peer.id} className="flex items-center justify-between gap-2">
                  <span className="truncate font-bold">{peer.name}</span>
                  <span className="shrink-0 text-xs text-muted">{stateLabel(peer.state)}</span>
                </li>
              ))}
            </ul>
          )}
          <button type="button" className="mt-2 h-10 w-full rounded-full bg-line font-bold" onClick={() => gameApi()?.leaveMulti()}>
            Sair da sala e jogar solo
          </button>
        </div>
      ) : null}
    </div>
  );
}

function Joystick() {
  const baseRef = useRef<HTMLDivElement>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });

  function setFrom(event: React.PointerEvent<HTMLDivElement>) {
    const el = baseRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    let x = (event.clientX - (rect.left + rect.width / 2)) / (rect.width / 2);
    let y = (event.clientY - (rect.top + rect.height / 2)) / (rect.height / 2);
    const mag = Math.hypot(x, y);
    if (mag > 1) {
      x /= mag;
      y /= mag;
    }
    setKnob({ x, y });
    input.stickX = x;
    input.stickY = -y;
  }

  function end() {
    setKnob({ x: 0, y: 0 });
    input.stickX = 0;
    input.stickY = 0;
  }

  return (
    <div
      ref={baseRef}
      className="pointer-events-auto relative size-28 touch-none rounded-full bg-paper/80 shadow-card"
      onPointerDown={(event) => {
        event.currentTarget.setPointerCapture(event.pointerId);
        setFrom(event);
      }}
      onPointerMove={(event) => {
        if (event.currentTarget.hasPointerCapture(event.pointerId)) setFrom(event);
      }}
      onPointerUp={end}
      onPointerCancel={end}
      onLostPointerCapture={end}
      aria-label="Direção"
      role="slider"
      aria-valuenow={0}
    >
      <span
        className="absolute top-1/2 left-1/2 size-12 -translate-x-1/2 -translate-y-1/2 rounded-full bg-pine"
        style={{ transform: `translate(calc(-50% + ${knob.x * 32}px), calc(-50% + ${knob.y * 32}px))` }}
      />
    </div>
  );
}

function DialogCard() {
  const speaker = useGiro((s) => s.speaker);
  const place = useGiro((s) => s.place);
  const lines = useGiro((s) => s.lines);
  const lineIndex = useGiro((s) => s.lineIndex);
  const last = lineIndex >= lines.length - 1;

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 flex justify-center p-4 pb-28 sm:pb-8">
      <section className="pointer-events-auto w-full max-w-lg rounded-3xl bg-paper p-5 text-ink shadow-card">
        <p className="text-xs font-extrabold tracking-wide text-coral-deep uppercase">{place}</p>
        <h2 className="font-display text-2xl font-bold">{speaker}</h2>
        <p className="mt-2 min-h-16 text-base leading-relaxed">{lines[lineIndex]}</p>
        <button
          type="button"
          className="mt-3 h-12 w-full rounded-full bg-pine font-extrabold text-paper"
          onClick={() => gameApi()?.interact()}
        >
          {last ? "Fechar" : "Continuar"}
        </button>
      </section>
    </div>
  );
}

function PauseCard() {
  const mode = useGiro((s) => s.mode);

  return (
    <div className="pointer-events-none absolute inset-0 grid place-items-center bg-ink/35 p-4">
      <section className="pointer-events-auto max-h-[92dvh] w-full max-w-sm overflow-y-auto rounded-3xl bg-paper p-6 text-ink shadow-card">
        <h2 className="font-display text-3xl font-bold">Pausa</h2>
        <p className="mt-1 text-sm text-muted">
          A seta coral mostra o próximo recado. C devolve a câmera para trás.
          {mode === "multi" ? " No multiplayer o jogo dos outros não para." : ""}
        </p>
        <button type="button" className="mt-4 h-12 w-full rounded-full bg-coral font-extrabold text-paper" onClick={() => gameApi()?.resume()}>
          Continuar
        </button>
        <button type="button" className="mt-2 h-11 w-full rounded-full font-bold text-pine" onClick={() => gameApi()?.openHelp()}>
          Como andar
        </button>
        <div className="mt-2">
          <SettingsForm />
        </div>
        <button
          type="button"
          className="mt-2 inline-flex h-11 items-center gap-2 font-bold text-ink"
          onClick={() => gameApi()?.restart()}
        >
          <RotateCcw className="size-4" />
          Recomeçar a volta
        </button>
        <button type="button" className="mt-1 h-11 w-full rounded-full bg-line font-bold" onClick={() => gameApi()?.toTitle()}>
          {mode === "multi" ? "Sair da sala e voltar ao menu" : "Voltar ao menu"}
        </button>
      </section>
    </div>
  );
}

function HelpCard() {
  return (
    <div className="pointer-events-none absolute inset-0 grid place-items-center bg-ink/40 p-4">
      <section className="pointer-events-auto w-full max-w-sm rounded-3xl bg-paper p-6 text-ink shadow-card">
        <div className="flex items-start justify-between gap-3">
          <h2 className="font-display text-3xl font-bold">Controles</h2>
          <button type="button" className="grid size-11 place-items-center rounded-full bg-line" aria-label="Fechar" onClick={() => gameApi()?.closeHelp()}>
            <X className="size-5" />
          </button>
        </div>
        <ul className="mt-3 space-y-2 text-sm leading-relaxed">
          <li>Volante: W anda, S volta, A vira à esquerda, D à direita.</li>
          <li>Livre: o corpo segue a câmera. A vai para a esquerda da tela.</li>
          <li>Espaço ou o botão Pular faz o boneco pular. Shift ou Correr acelera.</li>
          <li>E ou Falar entrega o recado.</li>
          <li>Joystick ou setas (em Ajustes) andam e viram. Os botões de câmera giram, sobem, descem e dão zoom.</li>
          <li>Arraste a tela para dar uma espiada. A câmera volta sozinha.</li>
        </ul>
      </section>
    </div>
  );
}

function DoneCard() {
  const elapsed = useGiro((s) => s.elapsed);
  const best = useGiro((s) => s.best);
  const gameType = useGiro((s) => s.gameType);
  const chInfo = useGiro((s) => s.chInfo);
  const mode = useGiro((s) => s.mode);

  if (gameType === "challenges") {
    return (
      <div className="pointer-events-none absolute inset-0 flex items-end justify-center p-4 sm:items-center">
        <section className="pointer-events-auto w-full max-w-md rounded-3xl bg-paper p-6 text-ink shadow-card">
          <p className="text-xs font-extrabold tracking-[0.18em] text-pine uppercase">Todas as missões</p>
          <h2 className="font-display mt-1 text-4xl font-bold">{mode === "multi" ? "Vocês zeraram!" : "Você zerou!"}</h2>
          <p className="mt-2 text-base leading-relaxed text-muted">Tempo total: {formatTime((chInfo?.totalMs ?? 0) / 1000)}.</p>
          <button type="button" className="mt-4 h-12 w-full rounded-full bg-coral font-extrabold text-paper" onClick={() => gameApi()?.startChallenges()}>
            Jogar de novo
          </button>
          <button type="button" className="mt-2 h-11 w-full rounded-full font-bold text-pine" onClick={() => gameApi()?.toTitle()}>
            Voltar ao menu
          </button>
        </section>
      </div>
    );
  }

  return (
    <div className="pointer-events-none absolute inset-0 flex items-end justify-center p-4 sm:items-center">
      <section className="pointer-events-auto w-full max-w-md rounded-3xl bg-paper p-6 text-ink shadow-card">
        <p className="text-xs font-extrabold tracking-[0.18em] text-pine uppercase">Volta fechada</p>
        <h2 className="font-display mt-1 text-4xl font-bold">Nenhuma carta no chão</h2>
        <p className="mt-2 text-base leading-relaxed text-muted">
          Tempo desta volta: {formatTime(elapsed)}. Melhor marca: {formatTime(best ?? elapsed)}.
        </p>
        <button type="button" className="mt-4 h-12 w-full rounded-full bg-coral font-extrabold text-paper" onClick={() => gameApi()?.begin(true)}>
          Outra volta
        </button>
        <button type="button" className="mt-2 h-11 w-full rounded-full font-bold text-pine" onClick={() => gameApi()?.toTitle()}>
          Voltar ao menu
        </button>
      </section>
    </div>
  );
}
