export type GiroApi = {
  begin: (fresh: boolean) => void;
  interact: () => void;
  pause: () => void;
  resume: () => void;
  restart: () => void;
  openHelp: () => void;
  closeHelp: () => void;
  centerCamera: () => void;
  jump: () => void;
  zoom: (delta: number) => void;
  startMulti: (room: string, name: string) => void;
  leaveMulti: () => void;
  toTitle: () => void;
  startChallenges: () => void;
  uiBlip: () => void;
};

let api: GiroApi | null = null;

export function registerApi(next: GiroApi | null) {
  api = next;
}

export function gameApi() {
  return api;
}
