import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { GiroOverlay } from "@/components/giro-ui";
import { mountGiro } from "@/game/engine";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    return mountGiro(canvas);
  }, []);

  // Só na versão publicada: guarda o jogo para o modo solo abrir sem internet.
  useEffect(() => {
    if (!import.meta.env.PROD || !("serviceWorker" in navigator)) return;
    navigator.serviceWorker.register("/sw.js").catch(() => {
      /* sem service worker o jogo continua funcionando, só não abre offline */
    });
  }, []);

  return (
    <main className="relative h-dvh w-full overflow-hidden bg-sky text-ink select-none">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" />
      <GiroOverlay />
    </main>
  );
}
