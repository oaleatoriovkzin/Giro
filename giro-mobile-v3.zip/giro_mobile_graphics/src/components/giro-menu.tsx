import { useEffect, useRef, useState } from "react";
import { gameApi } from "@/game/api";
import { cleanUsername, roomForUsername, type ControlMode, type Quality, type Resolution, type ScreenMode, type Settings } from "@/game/content";
import { peekRoom } from "@/game/net";
import { useGiro } from "@/game/store";

type Panel = "play" | "friends" | "settings" | "exit";
type Tab = "graphics" | "audio" | "control" | "profile";

const QUALITY: Array<[Quality, string]> = [
  ["baixa", "Baixa"],
  ["media", "Média"],
  ["alta", "Alta"],
  ["ultra", "Ultra"],
];
const RESOLUTION: Array<[Resolution, string]> = [
  ["baixa", "Baixa"],
  ["media", "Média"],
  ["alta", "Alta"],
];
const SCREEN: Array<[ScreenMode, string]> = [
  ["cheia", "Tela cheia"],
  ["janela", "Janela"],
  ["semborda", "Sem borda"],
];
const CONTROL: Array<[ControlMode, string]> = [
  ["touch", "Toque"],
  ["teclado", "Teclado"],
  ["gamepad", "Gamepad"],
];

const MIN_NAME = 2;

function Segment<T extends string>({
  options,
  value,
  onChange,
}: {
  options: Array<[T, string]>;
  value: T;
  onChange: (next: T) => void;
}) {
  return (
    <div className="segment" role="group">
      {options.map(([key, label]) => (
        <button key={key} type="button" className={key === value ? "selected" : ""} aria-pressed={key === value} onClick={() => onChange(key)}>
          {label}
        </button>
      ))}
    </div>
  );
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (next: boolean) => void }) {
  return (
    <div className="toggle-row">
      <span>{label}</span>
      <label className="switch">
        <input type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} aria-label={label} />
        <span />
      </label>
    </div>
  );
}

export function GiroMenu() {
  const ready = useGiro((s) => s.ready);
  const hasSave = useGiro((s) => s.hasSave);
  const username = useGiro((s) => s.username);
  const friends = useGiro((s) => s.friends);
  const settings = useGiro((s) => s.settings);
  const sensitivity = useGiro((s) => s.sensitivity);
  const padStyle = useGiro((s) => s.padStyle);
  const scheme = useGiro((s) => s.scheme);
  const invert = useGiro((s) => s.invert);
  const setSettings = useGiro((s) => s.setSettings);
  const setSensitivity = useGiro((s) => s.setSensitivity);
  const setPadStyle = useGiro((s) => s.setPadStyle);
  const setScheme = useGiro((s) => s.setScheme);
  const setInvert = useGiro((s) => s.setInvert);
  const setUsername = useGiro((s) => s.setUsername);
  const setFriends = useGiro((s) => s.setFriends);

  const [panel, setPanel] = useState<Panel>("play");
  const [tab, setTab] = useState<Tab>("graphics");
  const [draftName, setDraftName] = useState("");
  const [friendDraft, setFriendDraft] = useState("");
  const [online, setOnline] = useState<Record<string, number>>({});
  const [invite, setInvite] = useState("");
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const decided = useRef(false);

  function say(text: string) {
    setToast(text);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2600);
  }

  function click() {
    if (settings.menuSound) gameApi()?.uiBlip();
  }

  useEffect(() => {
    return () => {
      if (toastTimer.current) clearTimeout(toastTimer.current);
    };
  }, []);

  // Quando o jogo termina de carregar: sem username, o primeiro passo é escolher um. Convite no endereço também é lido aqui.
  useEffect(() => {
    if (!ready || decided.current) return;
    decided.current = true;
    const code = cleanUsername(new URLSearchParams(window.location.search).get("sala") ?? "");
    if (code) setInvite(code);
    if (!useGiro.getState().username) {
      setTab("profile");
      setPanel("settings");
    }
  }, [ready]);

  useEffect(() => {
    setDraftName(username);
  }, [username]);

  // Mostra quem dos amigos está com a sala aberta agora.
  useEffect(() => {
    if (panel !== "friends" || friends.length === 0) return;
    let stop = false;
    const run = async () => {
      const next: Record<string, number> = {};
      for (const friend of friends) next[friend] = await peekRoom(roomForUsername(friend));
      if (!stop) setOnline(next);
    };
    void run();
    const timer = setInterval(() => void run(), 7000);
    return () => {
      stop = true;
      clearInterval(timer);
    };
  }, [panel, friends]);

  function saveName() {
    const name = cleanUsername(draftName);
    if (name.length < MIN_NAME) {
      say("O username precisa ter pelo menos 2 letras ou números.");
      return;
    }
    const first = !username;
    setUsername(name);
    setDraftName(name);
    say(`Username salvo: @${name}`);
    if (first) setPanel("play");
  }

  function open(next: Panel, nextTab?: Tab) {
    click();
    setPanel(next);
    if (nextTab) setTab(nextTab);
  }

  function enterRoom(room: string, friend?: string) {
    click();
    if (!username) {
      say("Escolha o seu username primeiro.");
      setTab("profile");
      setPanel("settings");
      return;
    }
    if (friend && friend !== username && !friends.includes(friend)) setFriends([...friends, friend]);
    gameApi()?.startMulti(room, username);
    gameApi()?.startChallenges();
    if (invite) window.history.replaceState(null, "", window.location.pathname);
  }

  function addFriend() {
    const friend = cleanUsername(friendDraft);
    if (friend.length < MIN_NAME) {
      say("Digite o username do amigo (mínimo 2 letras ou números).");
      return;
    }
    if (friend === username) {
      say("Esse é você! Digite o username de outra pessoa.");
      return;
    }
    if (friends.includes(friend)) {
      say("Esse amigo já está na lista.");
      return;
    }
    setFriends([...friends, friend].slice(0, 30));
    setFriendDraft("");
    say(`@${friend} adicionado!`);
  }

  async function shareInvite() {
    click();
    if (!username) {
      say("Escolha o seu username primeiro.");
      return;
    }
    const url = `${window.location.origin}/?sala=${username}`;
    const text = `Entra na minha sala do Giro! Meu username é @${username}`;
    try {
      if (typeof navigator.share === "function") {
        await navigator.share({ title: "Giro", text, url });
        return;
      }
      await navigator.clipboard.writeText(`${text} ${url}`);
      say("Convite copiado! Cole no WhatsApp.");
    } catch {
      say(`Mande este link: ${url}`);
    }
  }

  function chooseScreenMode(mode: ScreenMode) {
    click();
    setSettings({ screenMode: mode });
    const doc = document.documentElement;
    try {
      if (mode === "janela") {
        if (document.fullscreenElement) void document.exitFullscreen();
      } else if (!document.fullscreenElement && typeof doc.requestFullscreen === "function") {
        void doc.requestFullscreen().catch(() => say("Este navegador não deixa entrar em tela cheia."));
      } else if (typeof doc.requestFullscreen !== "function") {
        say("Este navegador não tem tela cheia. No iPhone, use Adicionar à Tela de Início.");
      }
    } catch {
      say("Este navegador não deixa entrar em tela cheia.");
    }
  }

  const title: Record<Panel, string> = {
    play: "Jogar",
    friends: "Amigos",
    settings: "Configurações",
    exit: "Sair",
  };
  const icon: Record<Panel, string> = { play: "✦", friends: "☻", settings: "⚙", exit: "⇥" };
  const status: Record<Panel, string> = {
    play: "Pronto para jogar",
    friends: "Jogue com quem você quiser",
    settings: username ? "Personalize sua experiência" : "Comece escolhendo seu username",
    exit: "Encerrando sessão",
  };
  const sensitivityPct = Math.round(Math.max(1, Math.min(100, (sensitivity - 0.6) * 100)));

  return (
    <div className="gm" data-motion={settings.animations ? "on" : "off"}>
      <div className="scene" aria-hidden="true">
        <div className="stars" />
        <div className="orb" />
        <div className="horizon" />
      </div>
      <main className="layout">
        <section className="left">
          <div className="brand">
            <div className="logo">
              GIRO<span className="logo-mark">◉</span>
            </div>
            <div className="tagline">Seu mundo, do seu jeito</div>
          </div>
          <div className="profile-chip">
            <div className="avatar">♛</div>
            <div className="profile-text">
              <small>Jogador</small>
              <strong>{username ? `@${username}` : "Escolha seu username"}</strong>
            </div>
            <button type="button" className="edit-name" aria-label="Editar username" onClick={() => open("settings", "profile")}>
              ✎
            </button>
          </div>
          <nav className="menu" aria-label="Menu principal">
            <button type="button" className={`menu-btn ${panel === "play" ? "active" : ""}`} onClick={() => open("play")}>
              <span className="icon">▶</span>
              <span>Jogar</span>
              <span className="arrow">›</span>
            </button>
            <button type="button" className={`menu-btn ${panel === "friends" ? "active" : ""}`} onClick={() => open("friends")}>
              <span className="icon">☻</span>
              <span>Amigos</span>
              <span className="arrow">›</span>
            </button>
            <button type="button" className={`menu-btn ${panel === "settings" && tab !== "profile" ? "active" : ""}`} onClick={() => open("settings", "graphics")}>
              <span className="icon">⚙</span>
              <span>Configurações</span>
              <span className="arrow">›</span>
            </button>
            <button type="button" className={`menu-btn ${panel === "settings" && tab === "profile" ? "active" : ""}`} onClick={() => open("settings", "profile")}>
              <span className="icon">♙</span>
              <span>Perfil</span>
              <span className="arrow">›</span>
            </button>
            <button type="button" className={`menu-btn ${panel === "exit" ? "active" : ""}`} onClick={() => open("exit")}>
              <span className="icon">⇥</span>
              <span>Sair</span>
              <span className="arrow">›</span>
            </button>
          </nav>
          {settings.showTips ? (
            <div className="quote">
              Grandes jornadas
              <br />
              começam com um simples passo.
            </div>
          ) : null}
        </section>

        <section className="right">
          <div className="topline">
            <span className="status-dot" />
            <span>{status[panel]}</span>
            <span>•</span>
            <span>GIRO / MENU</span>
          </div>
          <div className="panel">
            <header className="panel-head">
              <span className="big-icon">{icon[panel]}</span>
              <h2>{panel === "settings" && tab === "profile" ? "Perfil" : title[panel]}</h2>
              <button type="button" className="close" aria-label="Voltar para Jogar" onClick={() => open("play")}>
                ×
              </button>
            </header>

            {panel === "play" ? (
              <div className="stack">
                {invite ? (
                  <div className="callout">
                    <strong>@{invite}</strong> convidou você para a sala dele.
                    <div style={{ height: 10 }} />
                    <button type="button" className="primary" disabled={!ready} onClick={() => enterRoom(roomForUsername(invite), invite)}>
                      Entrar na sala de @{invite}
                    </button>
                  </div>
                ) : null}
                <div className="section">
                  <div className="section-title">
                    <span>✦</span> Desafios em grupo
                  </div>
                  <p style={{ color: "#d7cfb9", lineHeight: 1.6, margin: "0 0 14px" }}>
                    6 missões de pular, correr e pegar tudo antes que o tempo acabe. Dá para jogar sozinho, mas é melhor com amigos.
                  </p>
                  <div className="stack">
                    <button
                      type="button"
                      className="primary"
                      disabled={!ready}
                      onClick={() => {
                        click();
                        gameApi()?.startChallenges();
                      }}
                    >
                      Jogar sozinho
                    </button>
                    <button type="button" className="secondary" onClick={() => open("friends")}>
                      Jogar com amigos ›
                    </button>
                  </div>
                </div>
                <div className="divider" />
                <div className="section">
                  <div className="section-title">
                    <span>✉</span> História do Giro
                  </div>
                  <p style={{ color: "#d7cfb9", lineHeight: 1.6, margin: "0 0 14px" }}>
                    Entregue 7 recados a pé, num planeta do tamanho de um quarteirão. Só você, no seu ritmo.
                  </p>
                  <div className="stack">
                    <button
                      type="button"
                      className="secondary"
                      disabled={!ready}
                      onClick={() => {
                        click();
                        gameApi()?.begin(!hasSave);
                      }}
                    >
                      {hasSave ? "Continuar a história" : "Começar a história"}
                    </button>
                    {hasSave ? (
                      <button
                        type="button"
                        className="ghost"
                        onClick={() => {
                          click();
                          gameApi()?.begin(true);
                        }}
                      >
                        Começar de novo
                      </button>
                    ) : null}
                  </div>
                </div>
              </div>
            ) : null}

            {panel === "friends" ? (
              <div className="stack">
                <div className="section">
                  <div className="section-title">
                    <span>♙</span> Seu username
                  </div>
                  {username ? (
                    <p style={{ margin: 0, color: "#d7cfb9" }}>
                      Você é <strong>@{username}</strong>.{" "}
                      <button type="button" className="ghost" style={{ display: "inline", padding: 0 }} onClick={() => open("settings", "profile")}>
                        Trocar
                      </button>
                    </p>
                  ) : (
                    <div className="callout">
                      <strong>Escreva seu username aqui:</strong> é assim que seus amigos encontram você.
                      <div style={{ height: 10 }} />
                      <input
                        className="field"
                        value={draftName}
                        maxLength={20}
                        autoCapitalize="none"
                        autoCorrect="off"
                        spellCheck={false}
                        placeholder="ex.: ana_01"
                        aria-label="Seu username"
                        onChange={(event) => setDraftName(cleanUsername(event.target.value))}
                      />
                      <div style={{ height: 10 }} />
                      <button type="button" className="primary" onClick={saveName}>
                        Salvar username
                      </button>
                    </div>
                  )}
                </div>
                <div className="section">
                  <div className="section-title">
                    <span>⌂</span> Sua sala
                  </div>
                  <p className="note" style={{ margin: "0 0 12px" }}>
                    Seus amigos entram digitando o seu username, ou pelo link de convite.
                  </p>
                  <div className="stack">
                    <button
                      type="button"
                      className="primary"
                      disabled={!ready || !username}
                      onClick={() => enterRoom(roomForUsername(username))}
                    >
                      Abrir minha sala
                    </button>
                    <button type="button" className="secondary" disabled={!username} onClick={() => void shareInvite()}>
                      Convidar por link
                    </button>
                  </div>
                </div>
                <div className="divider" />
                <div className="section">
                  <div className="section-title">
                    <span>＋</span> Adicionar amigo
                  </div>
                  <div style={{ display: "flex", gap: 8 }}>
                    <input
                      className="field"
                      value={friendDraft}
                      maxLength={20}
                      autoCapitalize="none"
                      autoCorrect="off"
                      spellCheck={false}
                      placeholder="username do amigo"
                      aria-label="Username do amigo"
                      onChange={(event) => setFriendDraft(cleanUsername(event.target.value))}
                      onKeyDown={(event) => {
                        if (event.key === "Enter") addFriend();
                      }}
                    />
                    <button type="button" className="mini" onClick={addFriend}>
                      Adicionar
                    </button>
                  </div>
                  <div className="stack" style={{ marginTop: 14 }}>
                    {friends.length === 0 ? (
                      <p className="note" style={{ margin: 0 }}>
                        Nenhum amigo ainda. Adicione pelo username e entre na sala dele quando ele estiver jogando.
                      </p>
                    ) : null}
                    {friends.map((friend) => {
                      const here = (online[friend] ?? 0) > 0;
                      return (
                        <div className="friend-row" key={friend}>
                          <span className={`dot ${here ? "on" : ""}`} aria-hidden="true" />
                          <span className="who">
                            @{friend}
                            <small>{here ? "com a sala aberta agora" : "sala vazia"}</small>
                          </span>
                          <button type="button" className="mini" disabled={!ready} onClick={() => enterRoom(roomForUsername(friend), friend)}>
                            Entrar
                          </button>
                          <button
                            type="button"
                            className="mini"
                            aria-label={`Remover @${friend}`}
                            onClick={() => setFriends(friends.filter((f) => f !== friend))}
                          >
                            ×
                          </button>
                        </div>
                      );
                    })}
                  </div>
                  <p className="note">
                    A conexão é direta entre os celulares, com até uns 8 jogadores por sala. O username não tem senha: quem digitar o mesmo username cai na mesma sala. Quem está na sala vê o IP dos outros, então jogue com quem você escolheu.
                  </p>
                </div>
              </div>
            ) : null}

            {panel === "settings" ? (
              <>
                <div className="tabs" role="tablist">
                  {(
                    [
                      ["graphics", "▣ Gráficos"],
                      ["audio", "♫ Áudio"],
                      ["control", "🎮 Controle"],
                      ["profile", "♙ Perfil"],
                    ] as Array<[Tab, string]>
                  ).map(([key, label]) => (
                    <button key={key} type="button" role="tab" aria-selected={tab === key} className={`tab ${tab === key ? "active" : ""}`} onClick={() => open("settings", key)}>
                      {label}
                    </button>
                  ))}
                </div>

                {tab === "graphics" ? (
                  <div className="panel-body">
                    <div className="section">
                      <div className="section-title">
                        <span>▣</span> Gráficos
                      </div>
                      <div className="label-row">
                        <label>Qualidade gráfica</label>
                      </div>
                      <Segment options={QUALITY} value={settings.quality} onChange={(quality) => (click(), setSettings({ quality }))} />
                      <div className="label-row">
                        <label>Resolução</label>
                      </div>
                      <Segment options={RESOLUTION} value={settings.resolution} onChange={(resolution) => (click(), setSettings({ resolution }))} />
                      <div className="label-row">
                        <label>Modo de tela</label>
                      </div>
                      <Segment options={SCREEN} value={settings.screenMode} onChange={chooseScreenMode} />
                      <div className="note">Qualidade alta pode consumir mais bateria e recursos do aparelho. Baixa desliga as sombras.</div>
                    </div>
                    <div className="section">
                      <div className="section-title">
                        <span>◉</span> Desempenho
                      </div>
                      <div className="label-row">
                        <label htmlFor="gm-fps">Limite de FPS</label>
                        <span className="value">{settings.fpsCap} FPS</span>
                      </div>
                      <input
                        id="gm-fps"
                        type="range"
                        min={30}
                        max={120}
                        step={30}
                        value={settings.fpsCap}
                        onChange={(event) => setSettings({ fpsCap: Number(event.target.value) })}
                      />
                      <Toggle label="Reduzir efeitos visuais" checked={settings.reducedFx} onChange={(reducedFx) => (click(), setSettings({ reducedFx }))} />
                      <Toggle label="Economia de bateria" checked={settings.battery} onChange={(battery) => (click(), setSettings({ battery }))} />
                    </div>
                  </div>
                ) : null}

                {tab === "audio" ? (
                  <div className="panel-body">
                    <div className="section">
                      <div className="section-title">
                        <span>♫</span> Áudio
                      </div>
                      {(
                        [
                          ["master", "Volume geral"],
                          ["music", "Música"],
                          ["effects", "Efeitos sonoros"],
                        ] as const
                      ).map(([key, label]) => (
                        <div key={key}>
                          <div className="label-row">
                            <label htmlFor={`gm-${key}`}>{label}</label>
                            <span className="value">{settings[key]}%</span>
                          </div>
                          <input
                            id={`gm-${key}`}
                            type="range"
                            min={0}
                            max={100}
                            value={settings[key]}
                            onChange={(event) => setSettings({ [key]: Number(event.target.value) } as Partial<Settings>)}
                          />
                        </div>
                      ))}
                    </div>
                    <div className="section">
                      <div className="section-title">
                        <span>◖</span> Preferências
                      </div>
                      <Toggle label="Som do menu" checked={settings.menuSound} onChange={(menuSound) => setSettings({ menuSound })} />
                      <Toggle label="Vibração (se disponível)" checked={settings.vibration} onChange={(vibration) => setSettings({ vibration })} />
                      <p className="note">Os volumes valem para o jogo todo. Zero em tudo deixa o jogo mudo.</p>
                    </div>
                  </div>
                ) : null}

                {tab === "control" ? (
                  <div className="panel-body">
                    <div className="section">
                      <div className="section-title">
                        <span>🎮</span> Modo de controle
                      </div>
                      <div className="label-row">
                        <label>Escolha como jogar</label>
                      </div>
                      <Segment options={CONTROL} value={settings.controlMode} onChange={(controlMode) => (click(), setSettings({ controlMode }))} />
                      <div className="label-row">
                        <label>Botões de andar (modo Toque)</label>
                      </div>
                      <Segment
                        options={[
                          ["stick", "Joystick"],
                          ["buttons", "Setas"],
                        ]}
                        value={padStyle}
                        onChange={(next) => (click(), setPadStyle(next))}
                      />
                      <div className="label-row">
                        <label>Jeito de andar</label>
                      </div>
                      <Segment
                        options={[
                          ["livre", "Livre"],
                          ["volante", "Volante"],
                        ]}
                        value={scheme}
                        onChange={(next) => (click(), setScheme(next))}
                      />
                      <div className="label-row">
                        <label htmlFor="gm-sens">Sensibilidade</label>
                        <span className="value">{sensitivityPct}%</span>
                      </div>
                      <input
                        id="gm-sens"
                        type="range"
                        min={1}
                        max={100}
                        value={sensitivityPct}
                        onChange={(event) => setSensitivity(0.6 + Number(event.target.value) / 100)}
                      />
                      <div className="label-row">
                        <label htmlFor="gm-dead">Zona morta do controle</label>
                        <span className="value">{settings.deadzone}%</span>
                      </div>
                      <input
                        id="gm-dead"
                        type="range"
                        min={0}
                        max={40}
                        value={settings.deadzone}
                        onChange={(event) => setSettings({ deadzone: Number(event.target.value) })}
                      />
                    </div>
                    <div className="section">
                      <div className="section-title">
                        <span>⌁</span> Assistência
                      </div>
                      <Toggle label="Inverter eixo vertical da câmera" checked={settings.invertY} onChange={(invertY) => (click(), setSettings({ invertY }))} />
                      <Toggle label="Inverter esquerda e direita ao virar" checked={invert} onChange={(next) => (click(), setInvert(next))} />
                      <p className="note">
                        Toque mostra os botões na tela. Teclado: setas/WASD, Espaço pula, Shift corre, C centraliza a câmera. Gamepad: analógico anda, A pula, B corre, Y centraliza, Start pausa.
                      </p>
                    </div>
                  </div>
                ) : null}

                {tab === "profile" ? (
                  <div className="panel-body">
                    <div className="section">
                      <div className="section-title">
                        <span>♙</span> Perfil do jogador
                      </div>
                      {!username ? (
                        <div className="callout" style={{ marginBottom: 14 }}>
                          <strong>Escreva seu username no campo abaixo.</strong> Seus amigos vão usar esse nome para entrar na sua sala.
                        </div>
                      ) : null}
                      <label className="label-row" htmlFor="gm-name">
                        Username
                      </label>
                      <input
                        id="gm-name"
                        className="field"
                        maxLength={20}
                        value={draftName}
                        autoCapitalize="none"
                        autoCorrect="off"
                        spellCheck={false}
                        placeholder="ex.: ana_01"
                        autoComplete="username"
                        onChange={(event) => setDraftName(cleanUsername(event.target.value))}
                        onKeyDown={(event) => {
                          if (event.key === "Enter") saveName();
                        }}
                      />
                      <p className="note">Use de 2 a 20 letras minúsculas, números, _ ou -. Sem espaço nem acento.</p>
                      <div style={{ height: 14 }} />
                      <button type="button" className="primary" onClick={saveName}>
                        Salvar perfil
                      </button>
                    </div>
                    <div className="section">
                      <div className="section-title">
                        <span>✦</span> Sua jornada
                      </div>
                      <Toggle label="Mostrar dicas no menu" checked={settings.showTips} onChange={(showTips) => setSettings({ showTips })} />
                      <Toggle label="Animações de fundo" checked={settings.animations} onChange={(animations) => setSettings({ animations })} />
                      <p className="note">As opções ficam salvas neste navegador, neste aparelho.</p>
                    </div>
                  </div>
                ) : null}
              </>
            ) : null}

            {panel === "exit" ? (
              <div className="section">
                <div className="section-title">
                  <span>↗</span> Até a próxima!
                </div>
                <p style={{ color: "#d7cfb9", lineHeight: 1.7 }}>
                  Você pode fechar esta aba para sair do Giro. Navegadores não permitem que uma página feche livremente uma aba aberta pelo usuário.
                </p>
                <button type="button" className="primary" onClick={() => open("play")}>
                  Voltar ao menu
                </button>
              </div>
            ) : null}
          </div>
        </section>
      </main>
      <div className="watermark">
        by <b>Plosbi Labs</b> ✦
      </div>
      <div className={`toast ${toast ? "show" : ""}`} role="status">
        {toast}
      </div>
    </div>
  );
}
