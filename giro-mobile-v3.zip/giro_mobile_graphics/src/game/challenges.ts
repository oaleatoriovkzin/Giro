import * as THREE from "three";
import { RADIUS, placeById, type NpcId } from "@/game/content";
import type { ChInfo } from "@/game/store";
import { orientUp, surfacePoint } from "@/game/world";

export type ChallengeKind = "collect" | "race" | "gather" | "stars";

export type Challenge = {
  title: string;
  hint: string;
  kind: ChallengeKind;
  /** coletar: itens · corrida: anéis · farol: segundos juntos · estrelas: estrelas */
  goal: number;
  /** segundos, só para corrida e estrelas */
  limit?: number;
};

export const CHALLENGES: Challenge[] = [
  {
    title: "Cartas ao vento",
    hint: "O vento espalhou 8 cartas. Azul é só andar, amarela pede um pulinho, vermelha pede pulo cheio!",
    kind: "collect",
    goal: 8,
  },
  {
    title: "Corrida do carteiro",
    hint: "Passe pelos 5 anéis na ordem antes do tempo acabar. Vale qualquer um do grupo!",
    kind: "race",
    goal: 5,
    limit: 55,
  },
  {
    title: "Balões altos",
    hint: "10 balões no ar. Pule na hora certa: os vermelhos só pegam no alto do pulo.",
    kind: "collect",
    goal: 10,
  },
  {
    title: "Todos no farol",
    hint: "Todo mundo junto perto do farol por 8 segundos. Se alguém sair, zera.",
    kind: "gather",
    goal: 8,
  },
  {
    title: "Estrelas saltitantes",
    hint: "6 estrelas pulam de lugar a cada 8 s. Peguem todas em 75 s e dividam as estrelas!",
    kind: "stars",
    goal: 6,
    limit: 75,
  },
  {
    title: "A grande volta",
    hint: "Corrida final: 6 anéis pelo planeta inteiro em 50 s. Corram!",
    kind: "race",
    goal: 6,
    limit: 50,
  },
];

const RACE_ROUTES: Record<number, NpcId[]> = {
  1: ["sol", "rosa", "nico", "luna", "nuvem"],
  5: ["sol", "rosa", "nico", "luna", "nuvem", "bia"],
};

/** Alturas (m) dos itens das missões de coleta: 0.9 anda, 1.7 pulinho, 2.3 pulo cheio. */
const COLLECT_HEIGHTS: Record<number, number[]> = {
  0: [0.9, 0.9, 0.9, 1.7, 1.7, 1.7, 2.3, 2.3],
  2: [1.7, 1.7, 1.7, 2.3, 1.7, 2.3, 2.3, 1.7, 2.3, 2.3],
};
const COLLECT_LON: Record<number, [number, number]> = {
  0: [-0.2, 3.4],
  2: [3.0, 6.2],
};

const PREP_MS = 6000;
const FAIL_MS = 5000;
const STAR_SLOT_MS = 8000;
const SYNC_EVERY_MS = 2500;
const PICK_RADIUS = 1.5;
const STAR_RADIUS = 1.7;
const RING_RADIUS = 2.5;
const GATHER_RADIUS = 5.5;

/** Estado compartilhado: é isso que viaja entre os jogadores. */
export type ChMessage = {
  t: "ch";
  /** índice da missão atual (== total quando todas acabaram) */
  i: number;
  /** quando a missão atual começou (ms, relógio do aparelho) */
  at: number;
  /** quando a primeira missão começou */
  t0: number;
  /** tentativa atual (corrida e estrelas) */
  a: number;
  /** itens pegos nesta tentativa */
  got: number[];
  /** anéis já passados nesta tentativa */
  cp: number;
  /** quando todas acabaram, se acabaram */
  end: number;
};

export function parseChMessage(data: unknown): ChMessage | null {
  if (!data || typeof data !== "object") return null;
  const d = data as Record<string, unknown>;
  if (d.t !== "ch") return null;
  const int = (v: unknown, min: number, max: number) =>
    typeof v === "number" && Number.isFinite(v) ? Math.max(min, Math.min(max, Math.floor(v))) : null;
  const i = int(d.i, 0, CHALLENGES.length);
  const a = int(d.a, 0, 999);
  const cp = int(d.cp, 0, 99);
  const at = typeof d.at === "number" && Number.isFinite(d.at) ? d.at : null;
  const t0 = typeof d.t0 === "number" && Number.isFinite(d.t0) ? d.t0 : null;
  const end = typeof d.end === "number" && Number.isFinite(d.end) ? d.end : 0;
  if (i == null || a == null || cp == null || at == null || t0 == null) return null;
  const got = Array.isArray(d.got)
    ? d.got.filter((n): n is number => typeof n === "number" && Number.isInteger(n) && n >= 0 && n < 64).slice(0, 64)
    : [];
  return { t: "ch", i, at, t0, a, got, cp, end };
}

function seeded(n: number) {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
}

type Spot = { lat: number; lon: number };

type Item = {
  id: number;
  base: THREE.Vector3;
  up: THREE.Vector3;
  tangent: THREE.Vector3;
  h: number;
  mesh: THREE.Object3D;
};

export type Others = Array<{ pos: THREE.Vector3; height: number }>;

export type ChallengeDeps = {
  scene: THREE.Scene;
  getPlayer: () => { pos: THREE.Vector3; height: number };
  /** Outros jogadores visíveis agora. */
  getOthers: () => Others;
  /** Quantos outros jogadores estão conectados (para saber quantos precisam ir ao farol). */
  getConnectedPeers: () => number;
  /** Só manda estado se existir sala. */
  send: (msg: ChMessage) => void;
  onSound: (kind: "pick" | "check" | "win" | "fail") => void;
  onInfo: (info: ChInfo) => void;
  onToast: (text: string) => void;
};

const _b = new THREE.Vector3();
const _face = new THREE.Vector3();

export function createChallenges(deps: ChallengeDeps) {
  const group = new THREE.Group();
  group.name = "challenges";
  deps.scene.add(group);

  const letterGeo = new THREE.BoxGeometry(0.62, 0.42, 0.06);
  const sealGeo = new THREE.SphereGeometry(0.07, 8, 6);
  const balloonGeo = new THREE.SphereGeometry(0.4, 16, 12);
  const knotGeo = new THREE.ConeGeometry(0.07, 0.14, 8);
  const starGeo = new THREE.IcosahedronGeometry(0.42, 0);
  const ringGeo = new THREE.TorusGeometry(RING_RADIUS, 0.14, 8, 36);
  const beamGeo = new THREE.CylinderGeometry(0.7, 0.7, 7, 16, 1, true);
  const gatherRingGeo = new THREE.TorusGeometry(GATHER_RADIUS, 0.18, 8, 48);

  const colorFor = (h: number) => (h > 2 ? 0xd9483b : h > 1.3 ? 0xf2c14e : 0x4a90c8);
  const mats = new Map<number, THREE.MeshStandardMaterial>();
  const matFor = (color: number) => {
    let m = mats.get(color);
    if (!m) {
      m = new THREE.MeshStandardMaterial({ color, roughness: 0.5, emissive: color, emissiveIntensity: 0.28 });
      mats.set(color, m);
    }
    return m;
  };
  const cream = new THREE.MeshStandardMaterial({ color: 0xf4efe4, roughness: 0.7, emissive: 0xf4efe4, emissiveIntensity: 0.18 });
  const gold = new THREE.MeshStandardMaterial({ color: 0xffd45c, roughness: 0.35, emissive: 0xffb300, emissiveIntensity: 0.7 });
  const coralMat = new THREE.MeshStandardMaterial({ color: 0xe07a5f, roughness: 0.5, emissive: 0xe07a5f, emissiveIntensity: 0.5 });
  const beamMat = new THREE.MeshBasicMaterial({ color: 0xffe08a, transparent: true, opacity: 0.28, depthWrite: false, side: THREE.DoubleSide });
  const gatherMat = new THREE.MeshStandardMaterial({ color: 0xfff1b8, roughness: 0.4, emissive: 0xffd45c, emissiveIntensity: 0.8 });
  const stringMat = new THREE.LineBasicMaterial({ color: 0xf4efe4 });

  // ───────── estado ─────────
  let active = false;
  let index = 0;
  let startedAt = 0;
  let t0 = 0;
  let endedAt = 0;
  let attempt = 0;
  let cp = 0;
  let got = new Set<number>();
  let hold = 0;
  let lastSync = 0;
  let lastInfo = 0;
  let lastFailToast = -1;
  let items: Item[] = [];
  let stars: Array<{ mesh: THREE.Mesh; id: number; base: THREE.Vector3; up: THREE.Vector3 }> = [];
  let ring: THREE.Group | null = null;
  let gatherGroup: THREE.Group | null = null;
  let built = -1;

  function clearObjects() {
    for (const child of [...group.children]) group.remove(child);
    items = [];
    stars = [];
    ring = null;
    gatherGroup = null;
    built = -1;
  }

  function spotFor(mission: number, n: number, count: number): Spot {
    const [from, to] = COLLECT_LON[mission] ?? [0, 6];
    const lon = from + ((to - from) * (n + 0.5 + (seeded(mission * 53 + n) - 0.5) * 0.7)) / count;
    const lat = (seeded(mission * 97 + n * 7 + 3) - 0.5) * 0.8;
    return { lat, lon };
  }

  function starSpot(id: number, slot: number): Spot {
    const anchor = id * ((Math.PI * 2) / 6) + 0.3;
    return {
      lat: (seeded(id * 31 + slot * 7 + 1) - 0.5) * 0.9,
      lon: anchor + (seeded(id * 17 + slot * 13 + 5) - 0.5) * 1.1,
    };
  }

  function makeLetter(h: number) {
    const g = new THREE.Group();
    g.add(new THREE.Mesh(letterGeo, matFor(colorFor(h))));
    const seal = new THREE.Mesh(sealGeo, cream);
    seal.position.z = 0.05;
    g.add(seal);
    return g;
  }

  function makeBalloon(h: number) {
    const g = new THREE.Group();
    const body = new THREE.Mesh(balloonGeo, matFor(colorFor(h)));
    body.scale.set(1, 1.2, 1);
    g.add(body);
    const knot = new THREE.Mesh(knotGeo, matFor(colorFor(h)));
    knot.position.y = -0.5;
    knot.rotation.x = Math.PI;
    g.add(knot);
    const line = new THREE.Line(
      new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, -0.56, 0), new THREE.Vector3(0, -1.0, 0)]),
      stringMat,
    );
    g.add(line);
    return g;
  }

  function build(mission: number) {
    clearObjects();
    built = mission;
    const def = CHALLENGES[mission];
    if (!def) return;
    if (def.kind === "collect") {
      const heights = COLLECT_HEIGHTS[mission] ?? [];
      heights.forEach((h, n) => {
        const spot = spotFor(mission, n, heights.length);
        const base = surfacePoint(spot.lat, spot.lon);
        const up = base.clone().normalize();
        const tangent = new THREE.Vector3(0, 1, 0).cross(up).normalize();
        const mesh = mission === 0 ? makeLetter(h) : makeBalloon(h);
        group.add(mesh);
        items.push({ id: n, base, up, tangent, h, mesh });
      });
    } else if (def.kind === "race") {
      ring = new THREE.Group();
      const torus = new THREE.Mesh(ringGeo, coralMat);
      torus.rotation.x = Math.PI / 2;
      const beam = new THREE.Mesh(beamGeo, beamMat);
      beam.position.y = 3.5;
      ring.add(torus, beam);
      group.add(ring);
    } else if (def.kind === "gather") {
      gatherGroup = new THREE.Group();
      const torus = new THREE.Mesh(gatherRingGeo, gatherMat);
      torus.rotation.x = Math.PI / 2;
      torus.position.y = 0.1;
      const beam = new THREE.Mesh(beamGeo, beamMat);
      beam.scale.set(3.2, 1.6, 3.2);
      beam.position.y = 5;
      gatherGroup.add(torus, beam);
      group.add(gatherGroup);
    } else {
      for (let id = 0; id < def.goal; id += 1) {
        const mesh = new THREE.Mesh(starGeo, gold);
        group.add(mesh);
        stars.push({ mesh, id, base: new THREE.Vector3(), up: new THREE.Vector3(0, 1, 0) });
      }
    }
  }

  function snapshot(): ChMessage {
    return { t: "ch", i: index, at: startedAt, t0, a: attempt, got: [...got], cp, end: endedAt };
  }

  function push(now: number) {
    lastSync = now;
    deps.send(snapshot());
  }

  function restart(now: number) {
    index = 0;
    startedAt = now;
    t0 = now;
    endedAt = 0;
    attempt = 0;
    cp = 0;
    got = new Set();
    hold = 0;
    lastFailToast = -1;
    build(0);
    push(now);
  }

  function complete(now: number) {
    deps.onSound("win");
    index += 1;
    startedAt = now;
    attempt = 0;
    cp = 0;
    got = new Set();
    hold = 0;
    lastFailToast = -1;
    if (index >= CHALLENGES.length) {
      endedAt = now;
      clearObjects();
    } else {
      build(index);
    }
    deps.onToast(index >= CHALLENGES.length ? "Todas as missões cumpridas!" : "Missão cumprida!");
    push(now);
  }

  /** Junta o estado de outro jogador com o nosso. Vale o mais adiantado; empates ficam com o início mais antigo. */
  function merge(msg: ChMessage) {
    t0 = Math.min(t0, msg.t0);
    if (msg.i > index) {
      index = msg.i;
      startedAt = msg.at;
      attempt = msg.a;
      got = new Set(msg.got);
      cp = msg.cp;
      hold = 0;
      endedAt = msg.end;
      if (index >= CHALLENGES.length) clearObjects();
      else build(index);
      return;
    }
    if (msg.i < index) return;
    if (msg.at < startedAt) startedAt = msg.at;
    if (msg.end && !endedAt) endedAt = msg.end;
    if (msg.a === attempt) {
      for (const id of msg.got) got.add(id);
      cp = Math.max(cp, msg.cp);
    } else if (msg.a > attempt) {
      attempt = msg.a;
      got = new Set(msg.got);
      cp = msg.cp;
    }
  }

  function placeOnSurface(obj: THREE.Object3D, base: THREE.Vector3, up: THREE.Vector3, lift: number, spin: number, tangent?: THREE.Vector3) {
    obj.position.copy(base).addScaledVector(up, lift);
    const t = tangent ?? _b.set(0, 1, 0).cross(up).normalize();
    _face.copy(t).applyAxisAngle(up, spin);
    orientUp(obj, up, _face);
  }

  function fmt(seconds: number) {
    const s = Math.max(0, Math.ceil(seconds));
    return `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;
  }

  function update(dt: number, nowMs: number, playing: boolean) {
    if (!active) return;
    const def = CHALLENGES[index];

    if (!def) {
      if (performance.now() - lastInfo > 200) {
        lastInfo = performance.now();
        deps.onInfo({
          index: CHALLENGES.length,
          total: CHALLENGES.length,
          title: "Tudo cumprido",
          hint: "",
          progress: "",
          time: "",
          phase: "done",
          msg: "Vocês zeraram todas as missões!",
          totalMs: Math.max(0, (endedAt || nowMs) - t0),
        });
      }
      return;
    }
    if (built !== index) build(index);

    const player = deps.getPlayer();
    const sinceStart = nowMs - startedAt;
    const prepLeft = PREP_MS - sinceStart;
    let phase: ChInfo["phase"] = "go";
    let within = 0;
    if (prepLeft > 0) phase = "prep";
    const timed = def.limit != null;
    if (phase !== "prep" && timed && def.limit != null) {
      const period = def.limit * 1000 + FAIL_MS;
      const elapsed = nowMs - startedAt - PREP_MS;
      const n = Math.floor(elapsed / period);
      within = elapsed - n * period;
      if (n !== attempt) {
        attempt = n;
        cp = 0;
        got = new Set();
        hold = 0;
      }
      if (within >= def.limit * 1000) {
        phase = "fail";
        if (lastFailToast !== attempt) {
          lastFailToast = attempt;
          deps.onSound("fail");
          deps.onToast("Tempo esgotado! Vamos de novo");
        }
      }
    } else if (phase !== "prep") {
      within = nowMs - startedAt - PREP_MS;
    }

    const live = playing && phase === "go";
    const bodyY = player.height + 0.9;
    const clockSec = nowMs / 1000;

    // ─── coleta ───
    if (def.kind === "collect") {
      let changed = false;
      for (const item of items) {
        const taken = got.has(item.id);
        item.mesh.visible = !taken;
        const bob = Math.sin(clockSec * 2 + item.id) * 0.1;
        placeOnSurface(item.mesh, item.base, item.up, item.h + bob, clockSec * 1.4 + item.id, item.tangent);
        if (!live || taken) continue;
        if (player.pos.distanceTo(item.base) < PICK_RADIUS && Math.abs(bodyY - item.h) < 0.7) {
          got.add(item.id);
          changed = true;
          deps.onSound("pick");
        }
      }
      if (changed) {
        if (got.size >= def.goal) {
          complete(nowMs);
          return;
        }
        push(nowMs);
      }
    }

    // ─── corrida ───
    if (def.kind === "race") {
      const route = RACE_ROUTES[index] ?? [];
      const next = route[cp];
      if (ring) {
        ring.visible = next != null && phase !== "fail";
        if (next) {
          const place = placeById(next);
          const base = surfacePoint(place.lat, place.lon + 1.8 / RADIUS);
          const rUp = base.clone().normalize();
          placeOnSurface(ring, base, rUp, 0.15, clockSec);
          const pulse = 1 + Math.sin(clockSec * 5) * 0.05;
          ring.scale.setScalar(pulse);
          if (live && player.pos.distanceTo(base) < RING_RADIUS) {
            cp += 1;
            deps.onSound("check");
            if (cp >= route.length) {
              complete(nowMs);
              return;
            }
            push(nowMs);
          }
        }
      }
    }

    // ─── farol ───
    let present = 0;
    let need = 1;
    if (def.kind === "gather") {
      const place = placeById("sol");
      const base = surfacePoint(place.lat, place.lon);
      const gUp = base.clone().normalize();
      if (gatherGroup) placeOnSurface(gatherGroup, base, gUp, 0.05, 0);
      need = 1 + deps.getConnectedPeers();
      const selfIn = player.pos.distanceTo(base) < GATHER_RADIUS;
      present = selfIn ? 1 : 0;
      for (const other of deps.getOthers()) {
        if (other.pos.distanceTo(base) < GATHER_RADIUS) present += 1;
      }
      if (live && selfIn && present >= need) hold += dt;
      else hold = Math.max(0, hold - dt * 3);
      if (live && hold >= def.goal) {
        complete(nowMs);
        return;
      }
    }

    // ─── estrelas ───
    if (def.kind === "stars") {
      const slot = Math.max(0, Math.floor(within / STAR_SLOT_MS));
      const slotLeft = STAR_SLOT_MS - (within - slot * STAR_SLOT_MS);
      let changed = false;
      for (const star of stars) {
        const taken = got.has(star.id);
        star.mesh.visible = !taken && phase !== "fail";
        const spot = starSpot(star.id, slot);
        star.base.copy(surfacePoint(spot.lat, spot.lon));
        star.up.copy(star.base).normalize();
        const blink = slotLeft < 1500 ? 0.7 + Math.abs(Math.sin(clockSec * 14)) * 0.5 : 1;
        placeOnSurface(star.mesh, star.base, star.up, 1.3 + Math.sin(clockSec * 3 + star.id) * 0.12, clockSec * 2);
        star.mesh.scale.setScalar(blink);
        if (!live || taken) continue;
        if (player.pos.distanceTo(star.base) < STAR_RADIUS && Math.abs(bodyY - 1.3) < 1.0) {
          got.add(star.id);
          changed = true;
          deps.onSound("pick");
        }
      }
      if (changed) {
        if (got.size >= def.goal) {
          complete(nowMs);
          return;
        }
        push(nowMs);
      }
    }

    if (nowMs - lastSync > SYNC_EVERY_MS) push(nowMs);

    if (performance.now() - lastInfo > 200) {
      lastInfo = performance.now();
      let progress = "";
      if (def.kind === "collect") progress = `${got.size}/${def.goal}`;
      else if (def.kind === "race") progress = `${cp}/${def.goal} anéis`;
      else if (def.kind === "stars") progress = `${got.size}/${def.goal} estrelas`;
      else progress = `${present}/${need} no farol · ${Math.floor(hold)}/${def.goal}s`;
      let time = "";
      if (phase === "go") {
        time = timed && def.limit != null ? fmt(def.limit - within / 1000) : fmt(within / 1000);
      }
      let msg = "";
      if (phase === "prep") msg = `Prepare-se… ${Math.max(1, Math.ceil(prepLeft / 1000))}`;
      if (phase === "fail") msg = "Tempo esgotado! Vamos de novo";
      deps.onInfo({
        index,
        total: CHALLENGES.length,
        title: def.title,
        hint: def.hint,
        progress,
        time,
        phase,
        msg,
        totalMs: 0,
      });
    }
  }

  return {
    /** Começa uma partida nova de desafios. */
    start(now: number) {
      active = true;
      restart(now);
    },
    /** Para e some com tudo (ao voltar ao menu ou ir para a história). */
    stop() {
      active = false;
      clearObjects();
    },
    restart,
    update,
    receive(data: unknown) {
      if (!active) return;
      const msg = parseChMessage(data);
      if (msg) merge(msg);
    },
    /** Reenvia o estado agora (quando alguém novo entra). */
    resend(now: number) {
      if (active) push(now);
    },
    dispose() {
      clearObjects();
      deps.scene.remove(group);
      for (const geo of [letterGeo, sealGeo, balloonGeo, knotGeo, starGeo, ringGeo, beamGeo, gatherRingGeo]) geo.dispose();
      for (const mat of [...mats.values(), cream, gold, coralMat, beamMat, gatherMat, stringMat]) mat.dispose();
    },
  };
}
