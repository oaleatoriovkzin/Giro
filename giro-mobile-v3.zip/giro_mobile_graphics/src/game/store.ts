import { create } from "zustand";
import {
  DEFAULT_SETTINGS,
  QUEST,
  SAVE_KEY,
  cleanUsername,
  sanitizeSettings,
  type PadStyle,
  type Settings,
  type SaveData,
  type Scheme,
  type Vec3Tuple,
} from "@/game/content";

export type Screen = "title" | "play" | "pause" | "dialog" | "done";

export type GameMode = "solo" | "multi";

export type GameType = "story" | "challenges";

/** O que o HUD mostra da missão em grupo (atualizado ~5 vezes por segundo). */
export type ChInfo = {
  index: number;
  total: number;
  title: string;
  hint: string;
  progress: string;
  time: string;
  phase: "prep" | "go" | "fail" | "done";
  msg: string;
  totalMs: number;
};

export type NetStatus = "off" | "connecting" | "online";

export type PeerView = {
  id: string;
  name: string;
  state: string;
};

type GiroState = {
  ready: boolean;
  screen: Screen;
  returnScreen: Screen;
  step: number;
  /** Passo da missão que abriu o diálogo atual: evita avançar duas vezes. */
  dialogStep: number;
  lineIndex: number;
  lines: string[];
  speaker: string;
  place: string;
  dialogAdvances: boolean;
  elapsed: number;
  best: number | null;
  scheme: Scheme;
  invert: boolean;
  sensitivity: number;
  camDist: number;
  muted: boolean;
  near: boolean;
  nearName: string;
  banner: string | null;
  hasSave: boolean;
  helpOpen: boolean;
  padStyle: PadStyle;
  username: string;
  friends: string[];
  settings: Settings;
  gameType: GameType;
  chInfo: ChInfo | null;
  mode: GameMode;
  netStatus: NetStatus;
  room: string;
  peers: PeerView[];
  pos: Vec3Tuple | null;
  fwd: Vec3Tuple | null;
};

type GiroActions = {
  patch: (partial: Partial<GiroState>) => void;
  setScheme: (scheme: Scheme) => void;
  setInvert: (invert: boolean) => void;
  setSensitivity: (sensitivity: number) => void;
  setCamDist: (camDist: number) => void;
  setMuted: (muted: boolean) => void;
  setPadStyle: (padStyle: PadStyle) => void;
  setUsername: (username: string) => void;
  setSettings: (partial: Partial<Settings>) => void;
  setFriends: (friends: string[]) => void;
};

export type HudTick = {
  meters: number;
  bearing: number;
  elapsed: number;
};

let hudListener: ((tick: HudTick) => void) | null = null;

export function onHudTick(listener: (tick: HudTick) => void) {
  hudListener = listener;
  return () => {
    if (hudListener === listener) hudListener = null;
  };
}

export function emitHudTick(tick: HudTick) {
  hudListener?.(tick);
}

const defaults: GiroState = {
  ready: false,
  screen: "title",
  returnScreen: "play",
  step: 0,
  dialogStep: -1,
  lineIndex: 0,
  lines: [],
  speaker: "",
  place: "",
  dialogAdvances: false,
  elapsed: 0,
  best: null,
  scheme: "livre",
  invert: false,
  sensitivity: 1,
  camDist: 6.4,
  muted: false,
  near: false,
  nearName: "",
  banner: null,
  hasSave: false,
  helpOpen: false,
  padStyle: "stick",
  username: "",
  friends: [],
  settings: DEFAULT_SETTINGS,
  gameType: "challenges",
  chInfo: null,
  mode: "solo",
  netStatus: "off",
  room: "",
  peers: [],
  pos: null,
  fwd: null,
};

const PERSISTED_KEYS = [
  "step",
  "elapsed",
  "best",
  "scheme",
  "invert",
  "sensitivity",
  "camDist",
  "muted",
  "padStyle",
  "username",
  "friends",
  "settings",
  "pos",
] as const;

function persist(state: GiroState) {
  const data: SaveData = {
    v: 1,
    step: state.step,
    elapsed: state.elapsed,
    best: state.best,
    scheme: state.scheme,
    invert: state.invert,
    sensitivity: state.sensitivity,
    camDist: state.camDist,
    muted: state.muted,
    username: state.username,
    friends: state.friends,
    settings: state.settings,
    pad: state.padStyle,
  };
  if (state.pos && state.fwd) {
    data.pos = state.pos;
    data.fwd = state.fwd;
  }
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(data));
  } catch {
    /* ignore quota */
  }
}

function isTuple(value: unknown): value is Vec3Tuple {
  return (
    Array.isArray(value) &&
    value.length === 3 &&
    value.every((n) => typeof n === "number" && Number.isFinite(n))
  );
}

/** Lê o save e descarta tudo que estiver estragado, em vez de quebrar o jogo. */
export function loadSave(): SaveData | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as Partial<SaveData>;
    if (data.v !== 1 || typeof data.step !== "number" || !Number.isFinite(data.step)) return null;
    const step = Math.max(0, Math.min(QUEST.length, Math.floor(data.step)));
    const elapsed = typeof data.elapsed === "number" && Number.isFinite(data.elapsed) ? Math.max(0, data.elapsed) : 0;
    const best = typeof data.best === "number" && Number.isFinite(data.best) ? data.best : null;
    return {
      v: 1,
      step,
      elapsed,
      best,
      scheme: data.scheme === "volante" ? "volante" : "livre",
      invert: data.invert === true,
      sensitivity: typeof data.sensitivity === "number" && Number.isFinite(data.sensitivity) ? Math.max(0.6, Math.min(1.6, data.sensitivity)) : 1,
      camDist: typeof data.camDist === "number" && Number.isFinite(data.camDist) ? Math.max(4.2, Math.min(9, data.camDist)) : 6.4,
      muted: data.muted === true,
      username: typeof data.username === "string" ? cleanUsername(data.username) : "",
      friends: Array.isArray(data.friends)
        ? [...new Set(data.friends.filter((f): f is string => typeof f === "string").map(cleanUsername).filter(Boolean))].slice(0, 30)
        : [],
      settings: sanitizeSettings(data.settings),
      pad: data.pad === "buttons" ? "buttons" : "stick",
      pos: isTuple(data.pos) ? data.pos : undefined,
      fwd: isTuple(data.fwd) ? data.fwd : undefined,
    };
  } catch {
    return null;
  }
}

export const useGiro = create<GiroState & GiroActions>((set, get) => ({
  ...defaults,
  patch: (partial) => {
    set(partial);
    if (PERSISTED_KEYS.some((key) => key in partial)) persist(get());
  },
  setScheme: (scheme) => {
    set({ scheme });
    persist(get());
  },
  setInvert: (invert) => {
    set({ invert });
    persist(get());
  },
  setSensitivity: (sensitivity) => {
    set({ sensitivity });
    persist(get());
  },
  setCamDist: (camDist) => {
    set({ camDist });
    persist(get());
  },
  setMuted: (muted) => {
    set({ muted });
    persist(get());
  },
  setPadStyle: (padStyle) => {
    set({ padStyle });
    persist(get());
  },
  setUsername: (username) => {
    set({ username });
    persist(get());
  },
  setSettings: (partial) => {
    set({ settings: { ...get().settings, ...partial } });
    persist(get());
  },
  setFriends: (friends) => {
    set({ friends });
    persist(get());
  },
}));

export function objectiveOf(step: number) {
  return QUEST[Math.min(step, QUEST.length - 1)]?.objective ?? "Volta fechada";
}

export function formatTime(seconds: number) {
  const safe = Math.max(0, Math.floor(seconds));
  const m = Math.floor(safe / 60);
  const s = safe % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}
